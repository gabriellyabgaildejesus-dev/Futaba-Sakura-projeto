import test, { after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "futaba-appeals-test-"));
process.env.DATA_DIR = tempDir;
const { loadAppealsStore, getAppealsGuild } = await import("../src/appeals-store.js");
const { getGuildConfig } = await import("../src/store.js");
const { handleAppealsApi } = await import("../src/appeals-api.js");
await loadAppealsStore();

const GUILD_ID = "111111111111111111";
const MEMBER = "222222222222222222";
const OTHER = "333333333333333333";
const BANNED = "444444444444444444";
const STAFF_A = "555555555555555555";
const STAFF_B = "666666666666666666";
const ROLE_VIEW = "777777777777777777";
const ROLE_ASSUME = "888888888888888888";
const ROLE_DECIDE = "999999999999999999";
const ROLE_MANAGE = "101010101010101010";
const rolesByUser = new Map([[STAFF_A,[ROLE_VIEW,ROLE_ASSUME,ROLE_DECIDE,ROLE_MANAGE]],[STAFF_B,[ROLE_VIEW,ROLE_ASSUME,ROLE_DECIDE]]]);
const members = new Map();
for (const id of [MEMBER, OTHER, STAFF_A, STAFF_B]) {
  const roleIds = rolesByUser.get(id) || [];
  members.set(id, {
    id,
    displayName: `user-${id.slice(-4)}`,
    user: { id, username: `user-${id.slice(-4)}`, globalName: `Nome ${id.slice(-4)}`, displayAvatarURL: () => `https://cdn.discordapp.com/avatars/${id}/hash.png` },
    permissions: { bitfield: 0n, has: () => false },
    roles: { cache: { has: roleId => roleIds.includes(roleId) } }
  });
}
const sentChannels = [];
const sentDMs = [];
const guild = {
  id: GUILD_ID,
  ownerId: "121212121212121212",
  members: { fetch: async ({ user }) => { if (!members.has(user)) throw new Error("Unknown member"); return members.get(user); } },
  bans: { fetch: async ({ user }) => { if (user === BANNED) return { user: { id: user } }; throw new Error("Not banned"); } }
};
const client = {
  users: { fetch: async id => ({ send: async message => { sentDMs.push({ id, message }); } }) },
  channels: { fetch: async id => ({ isTextBased: () => true, send: async payload => { sentChannels.push({ id, payload }); } }) }
};
const config = getGuildConfig(GUILD_ID);
config.appeals.active = true;
config.appeals.alertChannelId = "131313131313131313";
config.appeals.viewRoleIds = [ROLE_VIEW];
config.appeals.assumeRoleIds = [ROLE_ASSUME];
config.appeals.decideRoleIds = [ROLE_DECIDE];
config.appeals.manageRoleIds = [ROLE_MANAGE];
config.appeals.maxActivePerMember = 20;

function createResponse() {
  return {
    statusCode: 0, body: null,
    writeHead(statusCode) { this.statusCode = statusCode; },
    end(body) { this.body = JSON.parse(body); }
  };
}
async function call(method, route, userId, body = null) {
  const response = createResponse();
  const request = { method, testBody: body };
  const url = new URL(route, "http://localhost");
  const handled = await handleAppealsApi({
    client, guild, request, response, url,
    sendJson(res, status, payload) { res.statusCode = status; res.body = payload; },
    readJson: async req => req.testBody || {}
  });
  assert.equal(handled, true);
  return response;
}
const actor = id => ({ id, username: `user-${id.slice(-4)}`, globalName: `Nome ${id.slice(-4)}`, avatar: null });


test("identifica membros e contas banidas de forma diferente", async () => {
  const member = await call("GET", `/api/v1/guilds/${GUILD_ID}/appeals/eligibility?userId=${MEMBER}`, MEMBER);
  const banned = await call("GET", `/api/v1/guilds/${GUILD_ID}/appeals/eligibility?userId=${BANNED}`, BANNED);
  assert.equal(member.statusCode, 200);
  assert.equal(member.body.isMember, true);
  assert.equal(member.body.isBanned, false);
  assert.equal(banned.body.isBanned, true);
  assert.equal(banned.body.canSubmit, true);
});

test("Central desativada suspende novos envios sem bloquear o histórico existente", async () => {
  getGuildConfig(GUILD_ID).appeals.active = false;
  const eligibility = await call("GET", `/api/v1/guilds/${GUILD_ID}/appeals/eligibility?userId=${MEMBER}`, MEMBER);
  assert.equal(eligibility.statusCode, 200);
  assert.equal(eligibility.body.active, false);
  assert.equal(eligibility.body.canSubmit, false);
  const history = await call("GET", `/api/v1/guilds/${GUILD_ID}/appeals?userId=${MEMBER}&view=member`, MEMBER);
  assert.equal(history.statusCode, 200);
  const blocked = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals`, MEMBER, {
    action: "create", actor: actor(MEMBER), reason: "warn", dmAllowed: true,
    description: "Quero contestar esta advertência e apresentar o contexto completo."
  });
  assert.equal(blocked.statusCode, 503);
  getGuildConfig(GUILD_ID).appeals.active = true;
});

test("exige e-mail para banimento e confirmação de DM para Warn/Mute", async () => {
  const noEmail = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals`, BANNED, {
    action: "create", actor: actor(BANNED), reason: "ban", description: "Quero explicar o contexto do banimento."
  });
  assert.equal(noEmail.statusCode, 400);
  const noDm = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals`, MEMBER, {
    action: "create", actor: actor(MEMBER), reason: "warn", description: "Quero explicar o contexto da advertência."
  });
  assert.equal(noDm.statusCode, 400);
});

test("cria apelação persistente, envia alerta e restringe consulta ao dono ou staff", async () => {
  const created = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals`, MEMBER, {
    action: "create", actor: actor(MEMBER), reason: "warn", dmAllowed: true,
    description: "Quero contestar esta advertência e apresentar o contexto completo.", links: [], attachments: []
  });
  assert.equal(created.statusCode, 201);
  const id = created.body.appeal.id;
  assert.match(id, /^FUT-/);
  assert.equal(created.body.notification.delivered, true);
  assert.equal(sentChannels.length, 1);
  assert.ok(sentChannels[0].payload.content.includes(`/appeals-staff.html?id=${id}`));
  assert.equal(sentDMs.length, 1);
  assert.ok(sentDMs[0].message.includes(`/appeals.html?id=${id}`));
  const own = await call("GET", `/api/v1/guilds/${GUILD_ID}/appeals/${id}?userId=${MEMBER}`, MEMBER);
  assert.equal(own.statusCode, 200);
  assert.equal(own.body.access, "member");
  const unauthorized = await call("GET", `/api/v1/guilds/${GUILD_ID}/appeals/${id}?userId=${OTHER}`, OTHER);
  assert.equal(unauthorized.statusCode, 403);
  const staffList = await call("GET", `/api/v1/guilds/${GUILD_ID}/appeals?userId=${STAFF_A}&view=staff`, STAFF_A);
  assert.equal(staffList.statusCode, 200);
  assert.ok(staffList.body.appeals.some(item => item.id === id));
  assert.ok(getAppealsGuild(GUILD_ID).appeals.some(item => item.id === id));
  return id;
});

test("apelação de banimento envia confirmação por e-mail quando o provedor está configurado", async () => {
  const oldKey = process.env.APPEALS_EMAIL_API_KEY;
  const oldFrom = process.env.APPEALS_EMAIL_FROM;
  const oldFetch = globalThis.fetch;
  const requests = [];
  process.env.APPEALS_EMAIL_API_KEY = "resend-test-key";
  process.env.APPEALS_EMAIL_FROM = "POOL PARTY <test@example.com>";
  globalThis.fetch = async (url, options) => {
    requests.push({ url: String(url), body: JSON.parse(options.body) });
    return { ok: true, status: 200 };
  };
  try {
    const result = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals`, BANNED, {
      action: "create", actor: actor(BANNED), reason: "ban", email: "membro@example.com",
      description: "Quero solicitar a revisão do banimento e apresentar o contexto da situação.", links: [], attachments: []
    });
    assert.equal(result.statusCode, 201);
    assert.equal(result.body.contact.delivered, true);
    assert.equal(requests.length, 1);
    assert.equal(requests[0].url, "https://api.resend.com/emails");
    assert.ok(requests[0].body.html.includes(`/appeals.html?id=${result.body.appeal.id}`));
  } finally {
    globalThis.fetch = oldFetch;
    if (oldKey === undefined) delete process.env.APPEALS_EMAIL_API_KEY; else process.env.APPEALS_EMAIL_API_KEY = oldKey;
    if (oldFrom === undefined) delete process.env.APPEALS_EMAIL_FROM; else process.env.APPEALS_EMAIL_FROM = oldFrom;
  }
});

test("uma apelação só pode ser assumida por uma pessoa, mesmo em requisições concorrentes", async () => {
  const created = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals`, MEMBER, {
    action: "create", actor: actor(MEMBER), reason: "mute", dmAllowed: true,
    description: "Quero contestar o silenciamento e explicar o que aconteceu.", links: [], attachments: []
  });
  const id = created.body.appeal.id;
  const [first, second] = await Promise.all([
    call("PATCH", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/assume`, STAFF_A, { action: "assume", actor: actor(STAFF_A) }),
    call("PATCH", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/assume`, STAFF_B, { action: "assume", actor: actor(STAFF_B) })
  ]);
  const responses = [first, second];
  assert.equal(responses.filter(r => r.statusCode === 200).length, 1);
  assert.equal(responses.filter(r => r.statusCode === 409).length, 1);
  const conflict = responses.find(r => r.statusCode === 409);
  assert.match(conflict.body.error, /outro atendente já está/);
});

test("somente o responsável ou um gerente pode escrever no chat e adicionar notas internas", async () => {
  const created = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals`, MEMBER, {
    action: "create", actor: actor(MEMBER), reason: "warn", dmAllowed: true,
    description: "Quero contestar esta advertência e apresentar todos os esclarecimentos.", links: [], attachments: []
  });
  const id = created.body.appeal.id;
  const blockedMessage = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/messages`, STAFF_B, { actor: actor(STAFF_B), content: "Olá, vou analisar sua apelação." });
  assert.equal(blockedMessage.statusCode, 403);
  const blockedNote = await call("PATCH", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/internal-note`, STAFF_B, { actor: actor(STAFF_B), note: "Nota interna da equipe" });
  assert.equal(blockedNote.statusCode, 403);
  const assumed = await call("PATCH", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/assume`, STAFF_A, { action: "assume", actor: actor(STAFF_A) });
  assert.equal(assumed.statusCode, 200);
  const allowedMessage = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/messages`, STAFF_A, { actor: actor(STAFF_A), content: "Olá, vou analisar sua apelação." });
  assert.equal(allowedMessage.statusCode, 201);
  const allowedNote = await call("PATCH", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/internal-note`, STAFF_A, { actor: actor(STAFF_A), note: "Registro interno da equipe" });
  assert.equal(allowedNote.statusCode, 200);
});

test("decisões exigem cargo próprio e justificativa", async () => {
  const created = await call("POST", `/api/v1/guilds/${GUILD_ID}/appeals`, MEMBER, {
    action: "create", actor: actor(MEMBER), reason: "warn", dmAllowed: true,
    description: "Quero contestar uma advertência e apresentar meu esclarecimento.", links: [], attachments: []
  });
  const id = created.body.appeal.id;
  const bad = await call("PATCH", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/status`, STAFF_B, { action: "status", actor: actor(STAFF_B), status: "accepted", justification: "A equipe revisou e aprovou." });
  assert.equal(bad.statusCode, 403, "um atendente que não assumiu não pode decidir a apelação");
  const missing = await call("PATCH", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/status`, STAFF_A, { action: "status", actor: actor(STAFF_A), status: "accepted", justification: "Ok" });
  assert.equal(missing.statusCode, 400);
  const accepted = await call("PATCH", `/api/v1/guilds/${GUILD_ID}/appeals/${id}/status`, STAFF_A, { action: "status", actor: actor(STAFF_A), status: "accepted", justification: "A equipe revisou os fatos e aceitou o recurso." });
  assert.equal(accepted.statusCode, 200);
  assert.equal(accepted.body.appeal.status, "accepted");
});

after(async () => {
  await fs.rm(tempDir, { recursive: true, force: true });
});
