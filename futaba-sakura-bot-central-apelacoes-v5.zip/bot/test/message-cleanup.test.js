import test from "node:test";
import assert from "node:assert/strict";
import { fetchMemberMessagesInWindow, deleteFetchedMessages, purgeMemberMessagesInWindow } from "../src/message-cleanup.js";

function makeMessage(id, authorId, createdTimestamp) {
  return {
    id: String(id),
    author: { id: authorId },
    createdTimestamp,
    deleted: false,
    async delete() { this.deleted = true; }
  };
}

function makePaginatedChannel(messages) {
  const ordered = [...messages].sort((a, b) => b.createdTimestamp - a.createdTimestamp);
  const byId = new Map(ordered.map(item => [item.id, item]));
  const calls = [];
  const channel = {
    calls,
    messages: {
      async fetch({ limit = 100, before } = {}) {
        calls.push({ limit, before });
        const beforeIndex = before ? ordered.findIndex(item => item.id === before) : -1;
        const available = beforeIndex >= 0 ? ordered.slice(beforeIndex + 1) : ordered;
        return new Map(available.slice(0, limit).map(item => [item.id, item]));
      }
    },
    async bulkDelete(ids) {
      calls.push({ bulkDelete: ids.length });
      for (const id of ids) {
        const item = byId.get(id);
        if (item) item.deleted = true;
      }
      return ids;
    }
  };
  return channel;
}

test("janela encontra todas as mensagens do membro e exclui autores diferentes da seleção", async () => {
  const end = 1_800_000_000_000;
  const all = Array.from({ length: 245 }, (_, index) => makeMessage(
    index + 1,
    index % 3 === 0 ? "outro-membro" : "membro-alvo",
    end - (244 - index) * 1000
  ));
  const trigger = all.at(-1);
  trigger.channel = makePaginatedChannel(all);
  trigger.guild = { members: { me: { permissionsIn: () => ({ has: () => true }) } } };

  const result = await fetchMemberMessagesInWindow(trigger, 240);
  assert.ok(result.length > 100, "deve paginar além das primeiras 100 mensagens");
  assert.ok(result.every(item => item.author.id === "membro-alvo"));
  assert.ok(result.every(item => item.createdTimestamp >= end - 240_000 && item.createdTimestamp <= end));
  assert.ok(trigger.channel.calls.filter(call => call.limit === 100).length >= 2);
});

test("exclusão usa lotes de até 100 e contabiliza as mensagens", async () => {
  const messages = Array.from({ length: 237 }, (_, index) => makeMessage(index + 1, "membro", Date.now()));
  const channel = makePaginatedChannel(messages);
  const result = await deleteFetchedMessages(channel, messages);
  assert.deepEqual(result, { deletedCount: 237, failedCount: 0 });
  assert.deepEqual(channel.calls.filter(call => call.bulkDelete).map(call => call.bulkDelete), [100, 100, 37]);
  assert.ok(messages.every(item => item.deleted));
});

test("uma única mensagem é excluída individualmente", async () => {
  const message = makeMessage("1", "membro", Date.now());
  const channel = makePaginatedChannel([message]);
  const result = await deleteFetchedMessages(channel, [message]);
  assert.deepEqual(result, { deletedCount: 1, failedCount: 0 });
  assert.equal(message.deleted, true);
});

test("purga combina busca e exclusão sem incluir mensagens de outros membros", async () => {
  const end = 1_800_000_000_000;
  const messages = [
    makeMessage("1", "target", end - 3000),
    makeMessage("2", "other", end - 2000),
    makeMessage("3", "target", end - 1000)
  ];
  const trigger = messages[2];
  const channel = makePaginatedChannel(messages);
  trigger.channel = channel;
  trigger.guild = { members: { me: { permissionsIn: () => ({ has: () => true }) } } };
  const result = await purgeMemberMessagesInWindow(trigger, 5);
  assert.equal(result.matchedCount, 2);
  assert.equal(result.deletedCount, 2);
  assert.equal(messages[1].deleted, false);
});
