import test from "node:test";
import assert from "node:assert/strict";
import { createDefaultGuildConfig } from "../src/defaults.js";
import { applyGuildConfigPatch, serializeConfigForWeb, validateApiGuildAllowlist } from "../src/api-config.js";

test("API atualiza apenas a whitelist de bots confiáveis com IDs Discord válidos", () => {
  const base = createDefaultGuildConfig();
  const next = applyGuildConfigPatch(base, "antiBot", {
    trustedBotIds: ["123456789012345678", "234567890123456789"]
  });
  assert.deepEqual(next.antiBot.trustedBotIds, ["123456789012345678", "234567890123456789"]);
});

test("API rejeita IDs inválidos na whitelist do Anti-Bot", () => {
  assert.throws(() => applyGuildConfigPatch(createDefaultGuildConfig(), "antiBot", {
    trustedBotIds: ["not-a-discord-id"]
  }), /ID inválido/);
});

test("API não permite alterar hash/senha, pendências ou lista interna de bloqueios", () => {
  for (const field of ["password", "pending", "blockedBotIds"]) {
    assert.throws(() => applyGuildConfigPatch(createDefaultGuildConfig(), "antiBot", {
      [field]: {}
    }), /campo interno/);
  }
});

test("config enviada ao site omite hash, pendências e bloqueios internos", () => {
  const config = createDefaultGuildConfig();
  config.antiBot.password = { salt: "salt", hash: "hash" };
  config.antiBot.pending = { "123456789012345678": { deadline: 1 } };
  config.antiBot.blockedBotIds = ["123456789012345678"];
  const safe = serializeConfigForWeb(config);
  assert.equal(safe.antiBot.password, undefined);
  assert.equal(safe.antiBot.pending, undefined);
  assert.equal(safe.antiBot.blockedBotIds, undefined);
  assert.equal(safe.antiBot.passwordConfigured, true);
});

test("API atualiza texto configurável, mas valida limite e banner HTTPS", () => {
  const base = createDefaultGuildConfig();
  const next = applyGuildConfigPatch(base, "antiSpam", {
    publicMessage: "Aviso atualizado"
  });
  assert.equal(next.antiSpam.publicMessage, "Aviso atualizado");
  assert.throws(() => applyGuildConfigPatch(base, "antiSpam", {
    bannerUrl: "http://example.com/banner.png"
  }), /HTTPS/);
});


test("API exige allowlist com apenas o ID real do POOL PARTY", () => {
  const guildId = "123456789012345678";
  assert.deepEqual([...validateApiGuildAllowlist(guildId, guildId)], [guildId]);
  assert.throws(() => validateApiGuildAllowlist(guildId, ""), /API_ALLOWED_GUILD_IDS/);
  assert.throws(() => validateApiGuildAllowlist(guildId, `${guildId},234567890123456789`), /somente o mesmo ID/);
  assert.throws(() => validateApiGuildAllowlist("invalid", guildId), /POOL_PARTY_GUILD_ID/);
});


test("API permite personalizar as mensagens e estados do embed de autenticação Anti-Bot", () => {
  const base = createDefaultGuildConfig();
  const next = applyGuildConfigPatch(base, "antiBot", {
    authEmbedTitle: "Verificação da integração",
    authSuccessColor: "#12AB34",
    passwordIncorrectMessage: "A chave não confere."
  });
  assert.equal(next.antiBot.authEmbedTitle, "Verificação da integração");
  assert.equal(next.antiBot.authSuccessColor, "#12AB34");
  assert.equal(next.antiBot.passwordIncorrectMessage, "A chave não confere.");
  assert.throws(() => applyGuildConfigPatch(base, "antiBot", { authEmbedColor: "orange" }), /#RRGGBB/);
});

test("Central de Apelações começa desativada até configurar os responsáveis e o canal de alertas", () => {
  assert.equal(createDefaultGuildConfig().appeals.active, false);
});

test("Central de Apelações valida cargos, canal e limites sem expor dados internos", () => {
  const base = createDefaultGuildConfig();
  const next = applyGuildConfigPatch(base, "appeals", {
    active: true,
    alertChannelId: "123456789012345678",
    viewRoleIds: ["234567890123456789"],
    assumeRoleIds: ["345678901234567890"],
    decideRoleIds: ["456789012345678901"],
    manageRoleIds: ["567890123456789012"],
    maxActivePerMember: 2,
    maxAttachments: 6
  });
  assert.equal(next.appeals.active, true);
  assert.equal(next.appeals.alertChannelId, "123456789012345678");
  assert.deepEqual(next.appeals.assumeRoleIds, ["345678901234567890"]);
  assert.equal(next.appeals.maxActivePerMember, 2);
  assert.equal(next.appeals.maxAttachments, 6);
  assert.throws(() => applyGuildConfigPatch(base, "appeals", { assumeRoleIds: ["invalid"] }), /ID inválido/);
  assert.throws(() => applyGuildConfigPatch(base, "appeals", { alertChannelId: "invalid" }), /ID do Discord inválido/);
});
