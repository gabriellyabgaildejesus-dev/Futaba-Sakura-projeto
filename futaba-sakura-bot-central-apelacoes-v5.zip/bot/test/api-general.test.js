import test from "node:test";
import assert from "node:assert/strict";
import { createDefaultGuildConfig } from "../src/defaults.js";
import { applyGuildConfigPatch, serializeConfigForWeb } from "../src/api-config.js";

test("API aceita configuração geral do canal, prefixo e embed de punições", () => {
  const current = createDefaultGuildConfig();
  const next = applyGuildConfigPatch(current, "general", {
    logChannelId: "123456789012345678",
    prefix: "?",
    defaultClearCount: 75,
    punishmentEmbed: { title: "Julgamento", color: "#AABBCC", imageUrl: "https://example.com/banner.png", fields: ["Motivo|{reason}|false"], authorIconUrl: "https://example.com/icon.png", timestamp: false }
  });
  assert.equal(next.general.logChannelId, "123456789012345678");
  assert.equal(next.general.prefix, "?");
  assert.equal(next.general.defaultClearCount, 75);
  assert.equal(next.general.punishmentEmbed.title, "Julgamento");
  assert.equal(next.general.punishmentEmbed.color, "#AABBCC");
  assert.deepEqual(next.general.punishmentEmbed.fields, ["Motivo|{reason}|false"]);
  assert.equal(next.general.punishmentEmbed.timestamp, false);
});

test("API rejeita prefixo inválido, quantidade fora do limite e mídia sem HTTPS", () => {
  const current = createDefaultGuildConfig();
  assert.throws(() => applyGuildConfigPatch(current, "general", { prefix: "! @" }));
  assert.throws(() => applyGuildConfigPatch(current, "general", { defaultClearCount: 1001 }));
  assert.throws(() => applyGuildConfigPatch(current, "general", { punishmentEmbed: { imageUrl: "http://example.com/a.png" } }));
});

test("config enviada ao site não inclui histórico de punições ou snapshots de bloqueio", () => {
  const current = createDefaultGuildConfig();
  current.moderationHistory = [{ userId: "42", reason: "private" }];
  current.channelLocks = { "555": { snapshot: { secret: true } } };
  const safe = serializeConfigForWeb(current);
  assert.equal("moderationHistory" in safe, false);
  assert.equal("channelLocks" in safe, false);
});
