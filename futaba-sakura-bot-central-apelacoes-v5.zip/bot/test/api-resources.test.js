import test from "node:test";
import assert from "node:assert/strict";
import { serializeGuildResources } from "../src/api.js";

const collection = values => ({ values: () => values.values() });

test("API de recursos retorna apenas canais de texto enviáveis e cargos, ordenados", () => {
  const guild = {
    id: "111111111111111111",
    channels: { cache: collection([
      { id: "222222222222222222", name: "geral", type: 0, position: 2, parentName: "Comunidade", parentId: "333333333333333333", isThread: () => false, isTextBased: () => true, send() {} },
      { id: "444444444444444444", name: "avisos", type: 5, position: 1, parentName: "Comunidade", parentId: "333333333333333333", isThread: () => false, isTextBased: () => true, send() {} },
      { id: "555555555555555555", name: "voz", type: 2, position: 0, isThread: () => false, isTextBased: () => false },
      { id: "666666666666666666", name: "thread", type: 11, position: 0, isThread: () => true, isTextBased: () => true, send() {} }
    ]) },
    roles: { cache: collection([
      { id: "111111111111111111", name: "@everyone", position: 0 },
      { id: "777777777777777777", name: "Admin", position: 5, managed: false },
      { id: "888888888888888888", name: "Integração", position: 2, managed: true }
    ]) }
  };
  const result = serializeGuildResources(guild);
  assert.equal(result.guildId, guild.id);
  assert.deepEqual(result.channels.map(channel => channel.name), ["avisos", "geral"]);
  assert.deepEqual(result.roles.map(role => role.name), ["Admin", "Integração"]);
  assert.equal(result.roles[1].managed, true);
});
