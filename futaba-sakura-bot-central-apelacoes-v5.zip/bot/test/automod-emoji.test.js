import test from "node:test";
import assert from "node:assert/strict";
import { normalizeAutoModText } from "../src/security-utils.js";

test("AutoMod ignores emoji and keeps words separated around emoji", () => {
  assert.equal(normalizeAutoModText("😀😂🔥"), "");
  assert.equal(normalizeAutoModText("palavra😀proibida"), "palavra proibida");
  assert.equal(normalizeAutoModText("VOCÊ 💜 COME!"), "voce come");
  assert.equal(normalizeAutoModText("<:futaba:123456789012345678> alerta"), "alerta");
});

test("AutoMod normalization preserves searchable phrase words without emoji noise", () => {
  const term = normalizeAutoModText("palavra proibida");
  const message = normalizeAutoModText("essa é uma palavra 😀 proibida!");
  assert.equal(message.includes(term), true);
  assert.equal(normalizeAutoModText("comentário").split(" ").includes(normalizeAutoModText("come")), false);
});
