import test from "node:test";
import assert from "node:assert/strict";
import { parseMemberId, parseDuration, clearMessages } from "../src/moderation-command-utils.js";

test("parser de membro aceita menção simples, menção com ! e ID", () => {
  const id = "123456789012345678";
  assert.equal(parseMemberId(`<@${id}>`), id);
  assert.equal(parseMemberId(`<@!${id}>`), id);
  assert.equal(parseMemberId(id), id);
  assert.equal(parseMemberId("@alguem"), null);
});

test("parser de duração aceita s, m, h e d dentro do limite do Discord", () => {
  assert.equal(parseDuration("30s"), 30);
  assert.equal(parseDuration("10m"), 600);
  assert.equal(parseDuration("2h"), 7200);
  assert.equal(parseDuration("7d"), 604800);
  assert.equal(parseDuration("29d"), null);
  assert.equal(parseDuration("abc"), null);
  assert.equal(parseDuration("0m"), null);
});

test("!clear filtra membro, usa exclusão em massa para mensagens recentes e exclusão individual para antigas", async () => {
  const now = Date.now();
  const recentA = { id: "a", author: { id: "42" }, createdTimestamp: now - 1000, deleted: false, async delete() { this.deleted = true; } };
  const oldA = { id: "b", author: { id: "42" }, createdTimestamp: now - 15 * 24 * 60 * 60 * 1000, deleted: false, async delete() { this.deleted = true; } };
  const recentB = { id: "c", author: { id: "99" }, createdTimestamp: now - 2000 };
  const recentC = { id: "d", author: { id: "42" }, createdTimestamp: now - 3000 };
  const all = [recentA, oldA, recentB, recentC];
  let bulkIds = [];
  const channel = {
    messages: { async fetch() { return new Map(all.map(item => [item.id, item])); } },
    async bulkDelete(items) { bulkIds = [...items].map(item => item.id); return new Map(bulkIds.map(id => [id, true])); }
  };
  const result = await clearMessages(channel, 2, "42", now);
  assert.equal(result.matched, 2);
  assert.equal(result.deleted, 2);
  assert.deepEqual(bulkIds, []);
  assert.equal(recentA.deleted, true);
  assert.equal(oldA.deleted, true);
  assert.equal(result.failed, 0);
});
