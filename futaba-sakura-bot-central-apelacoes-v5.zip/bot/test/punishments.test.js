import test from "node:test";
import assert from "node:assert/strict";
import { applyConfiguredTimeout, describeTimeoutResult } from "../src/punishments.js";
import { scheduleMessageDeletion } from "../src/message-cleanup.js";

function makeGuildMember({ moderatable = true, permissions = true } = {}) {
  const calls = [];
  const member = {
    id: "123456789012345678",
    moderatable,
    calls,
    async timeout(milliseconds, reason) {
      calls.push({ milliseconds, reason });
      return this;
    }
  };
  const guild = {
    ownerId: "999999999999999999",
    members: {
      me: { permissions: { has: () => permissions } },
      async fetch() { return member; }
    }
  };
  return { member, guild };
}

test("mute usa exatamente os segundos configurados no módulo", async () => {
  const { member, guild } = makeGuildMember();
  const result = await applyConfiguredTimeout({ guild, member, author: { id: member.id } }, 37, "Anti-Spam");
  assert.equal(result.applied, true);
  assert.equal(result.durationSeconds, 37);
  assert.equal(member.calls[0].milliseconds, 37_000);
  assert.match(member.calls[0].reason, /Anti-Spam/);
});

test("mute busca o membro quando message.member não está disponível", async () => {
  const { member, guild } = makeGuildMember();
  const result = await applyConfiguredTimeout({ guild, member: null, author: { id: member.id } }, 120, "Anti-Flood");
  assert.equal(result.applied, true);
  assert.equal(member.calls[0].milliseconds, 120_000);
});

test("duração zero não aplica mute e informa que foi desativado", async () => {
  const { member, guild } = makeGuildMember();
  const result = await applyConfiguredTimeout({ guild, member, author: { id: member.id } }, 0, "Anti-Flood");
  assert.equal(result.applied, false);
  assert.equal(result.skipped, true);
  assert.equal(member.calls.length, 0);
  assert.match(describeTimeoutResult(result, 0), /desativado/);
});

test("mute informa falta de permissão Moderar membros", async () => {
  const { member, guild } = makeGuildMember({ permissions: false });
  const result = await applyConfiguredTimeout({ guild, member, author: { id: member.id } }, 60, "Spam de Menções");
  assert.equal(result.applied, false);
  assert.match(result.reason, /Moderar membros/);
  assert.equal(member.calls.length, 0);
});

test("mute informa bloqueio por hierarquia de cargos", async () => {
  const { member, guild } = makeGuildMember({ moderatable: false });
  const result = await applyConfiguredTimeout({ guild, member, author: { id: member.id } }, 60, "Anti-Spam");
  assert.equal(result.applied, false);
  assert.match(result.reason, /hierarquia/);
  assert.equal(member.calls.length, 0);
});

test("aviso público recebe temporizador próprio; atraso zero mantém o aviso", async () => {
  let callback;
  let delayMs;
  const notice = { deleted: false, async delete() { this.deleted = true; } };
  const timer = { unref() {} };
  const result = scheduleMessageDeletion(notice, 5, "aviso público", (fn, delay) => {
    callback = fn;
    delayMs = delay;
    return timer;
  });
  assert.deepEqual(result, { scheduled: true, delaySeconds: 5 });
  assert.equal(delayMs, 5000);
  await callback();
  assert.equal(notice.deleted, true);

  assert.deepEqual(scheduleMessageDeletion(notice, 0), { scheduled: false, reason: "atraso 0" });
});


test("uma segunda infração não reduz um timeout mais longo já aplicado", async () => {
  const { member, guild } = makeGuildMember();
  const message = { guild, member, guildId: "guild-timeout", author: { id: member.id } };
  const first = await applyConfiguredTimeout(message, 300, "Anti-Spam");
  assert.equal(first.applied, true);
  const second = await applyConfiguredTimeout(message, 60, "Anti-Flood");
  assert.equal(second.applied, false);
  assert.equal(second.alreadyActive, true);
  assert.equal(member.calls.length, 1, "não deve enviar uma segunda alteração que encurte o timeout");
  assert.match(describeTimeoutResult(second, 60), /preservada/);
});
