import test from "node:test";
import assert from "node:assert/strict";
import { classifyLinks } from "../src/links.js";
import { createPasswordRecord, verifyPassword, validateNewPassword } from "../src/password.js";
import { createDefaultGuildConfig } from "../src/defaults.js";
import { addAutoModTerms, parseAutoModTerms, removeAutoModTerms } from "../src/automod-terms.js";

test("GIF em URL com parâmetros e domínio Tenor entra na whitelist", () => {
  const config = createDefaultGuildConfig().antiLink;
  assert.equal(classifyLinks("https://media.tenor.com/example/clip.gif?width=640#frame", config).action, "allow");
  assert.equal(classifyLinks("https://giphy.com/gifs/example-slug", config).action, "allow");
});

test("blacklist prevalece sobre GIF e whitelist", () => {
  const config = createDefaultGuildConfig().antiLink;
  config.blacklist.push("bad.example");
  assert.equal(classifyLinks("https://bad.example/funny.gif?x=1", config).action, "block");
});

test("link fora das listas exige cargo autorizado ou é bloqueado pelo módulo", () => {
  const config = createDefaultGuildConfig().antiLink;
  assert.equal(classifyLinks("https://example.org/pagina", config).action, "review");
});

test("senha é guardada em hash e validada sem texto puro", async () => {
  const password = "FutabaSecure2026!";
  assert.equal(validateNewPassword(password), null);
  const record = await createPasswordRecord(password);
  assert.equal(record.hash.includes(password), false);
  assert.equal(await verifyPassword(password, record), true);
  assert.equal(await verifyPassword("SenhaErrada2026!", record), false);
});


test("GIF whitelist pode ser desligada sem remover a blacklist", () => {
  const config = createDefaultGuildConfig().antiLink;
  config.gifWhitelistEnabled = false;
  assert.equal(classifyLinks("https://cdn.example.com/image.gif?size=large", config).action, "review");
  config.blacklist.push("cdn.example.com");
  assert.equal(classifyLinks("https://cdn.example.com/image.gif", config).action, "block");
});

test("módulos de segurança começam desativados para evitar punições antes da configuração", () => {
  const config = createDefaultGuildConfig();
  assert.equal(Object.entries(config).filter(([key, value]) => value && typeof value === "object" && "enabled" in value).every(([, value]) => value.enabled === false), true);
});


test("AutoMod aceita mais de 100 termos e adiciona em lotes sem apagar os anteriores", () => {
  const firstBatch = parseAutoModTerms(Array.from({ length: 150 }, (_, index) => `termo-${index + 1}`).join("\n"));
  const secondBatch = parseAutoModTerms(Array.from({ length: 175 }, (_, index) => `palavra-${index + 1}`).join("\n"));
  const first = addAutoModTerms([], firstBatch);
  const second = addAutoModTerms(first.terms, secondBatch);
  assert.equal(first.terms.length, 150);
  assert.equal(second.terms.length, 325);
  assert.equal(second.added, 175);
});

test("AutoMod ignora duplicatas por maiúsculas e acentos e remove sem diferenciar", () => {
  const first = addAutoModTerms(["proibido"], parseAutoModTerms("PROIBIDO\nviolência"));
  assert.equal(first.added, 1);
  assert.deepEqual(first.terms, ["proibido", "violência"]);
  const removed = removeAutoModTerms(first.terms, parseAutoModTerms("VIOLENCIA"));
  assert.equal(removed.removed, 1);
  assert.deepEqual(removed.terms, ["proibido"]);
});
