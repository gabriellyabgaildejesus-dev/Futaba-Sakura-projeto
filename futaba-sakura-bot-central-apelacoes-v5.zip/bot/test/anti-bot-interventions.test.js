import { isTrustedAntiBot } from "../src/anti-bot-interventions.js";
import test from "node:test";
import assert from "node:assert/strict";
import { detectProtectedBotIntervention } from "../src/anti-bot-interventions.js";

const events = {
  ChannelOverwriteCreate: 13,
  ChannelOverwriteUpdate: 14,
  ChannelOverwriteDelete: 15,
  MemberBanRemove: 23,
  MemberUpdate: 24,
  MemberRoleUpdate: 25,
  RoleUpdate: 31
};

function makeConfig() {
  return {
    pending: {
      "bot-123": {
        botId: "bot-123",
        quarantineRoleId: "role-quarantine",
        originalRoleIds: ["role-original"]
      }
    },
    blockedBotIds: []
  };
}

test("detecta quando um administrador remove o timeout ativo do bot em quarentena", () => {
  const at = Date.parse("2026-11-25T19:00:00.000Z");
  const result = detectProtectedBotIntervention({
    action: events.MemberUpdate,
    targetId: "bot-123",
    createdTimestamp: at,
    changes: [{ key: "communication_disabled_until", old: "2026-12-02T19:00:00.000Z", new: null }]
  }, makeConfig(), events);

  assert.deepEqual(result, { botId: "bot-123", kind: "remoção ou redução do timeout (mute)" });
});

test("detecta quando o timeout do bot é encurtado", () => {
  const at = Date.parse("2026-11-25T19:00:00.000Z");
  const result = detectProtectedBotIntervention({
    action: events.MemberUpdate,
    targetId: "bot-123",
    createdTimestamp: at,
    changes: [{ key: "communication_disabled_until", old: "2026-12-02T19:00:00.000Z", new: "2026-11-26T19:00:00.000Z" }]
  }, makeConfig(), events);

  assert.equal(result?.botId, "bot-123");
});

test("não pune por alteração de apelido ou por extensão do timeout", () => {
  const at = Date.parse("2026-11-25T19:00:00.000Z");
  const config = makeConfig();
  assert.equal(detectProtectedBotIntervention({
    action: events.MemberUpdate,
    targetId: "bot-123",
    createdTimestamp: at,
    changes: [{ key: "nick", old: "Bot", new: "Bot seguro" }]
  }, config, events), null);

  assert.equal(detectProtectedBotIntervention({
    action: events.MemberUpdate,
    targetId: "bot-123",
    createdTimestamp: at,
    changes: [{ key: "communication_disabled_until", old: "2026-12-02T19:00:00.000Z", new: "2026-12-09T19:00:00.000Z" }]
  }, config, events), null);
});

test("detecta alteração de cargos do bot enquanto está em quarentena", () => {
  const result = detectProtectedBotIntervention({
    action: events.MemberRoleUpdate,
    targetId: "bot-123",
    changes: [{ key: "$add", new: [{ id: "role-original", name: "Bot Staff" }] }]
  }, makeConfig(), events);

  assert.equal(result?.botId, "bot-123");
  assert.match(result?.kind || "", /cargos/);
});

test("detecta alterações nas permissões do cargo de quarentena", () => {
  const result = detectProtectedBotIntervention({
    action: events.RoleUpdate,
    targetId: "role-quarantine",
    changes: [{ key: "permissions", old: "0", new: "8" }]
  }, makeConfig(), events);

  assert.equal(result?.botId, "bot-123");
  assert.match(result?.kind || "", /permissões/);
});

test("detecta alterações nas restrições do cargo de quarentena em um canal", () => {
  const result = detectProtectedBotIntervention({
    action: events.ChannelOverwriteDelete,
    targetId: "channel-1",
    extra: { id: "role-quarantine" },
    changes: [{ key: "deny", old: "1024", new: undefined }]
  }, makeConfig(), events);

  assert.equal(result?.botId, "bot-123");
});

test("não reage a eventos de outros membros", () => {
  const result = detectProtectedBotIntervention({
    action: events.MemberRoleUpdate,
    targetId: "member-999",
    changes: [{ key: "$add", new: [{ id: "role-original", name: "Bot Staff" }] }]
  }, makeConfig(), events);

  assert.equal(result, null);
});

test("detecta permissões de canal concedidas diretamente ao bot em quarentena", () => {
  const result = detectProtectedBotIntervention({
    action: events.ChannelOverwriteUpdate,
    targetId: "channel-1",
    extra: { id: "bot-123", type: "1" },
    changes: [{ key: "allow", old: "0", new: "1024" }]
  }, makeConfig(), events);

  assert.equal(result?.botId, "bot-123");
  assert.match(result?.kind || "", /diretamente ao bot/);
});

test("não pune quando a mudança de overwrite apenas aumenta a restrição", () => {
  const result = detectProtectedBotIntervention({
    action: events.ChannelOverwriteUpdate,
    targetId: "channel-1",
    extra: { id: "role-quarantine", type: "0" },
    changes: [{ key: "deny", old: "0", new: "1024" }]
  }, makeConfig(), events);

  assert.equal(result, null);
});


test("whitelist do Anti-Bot reconhece somente IDs cadastrados", () => {
  const antiBot = { trustedBotIds: ["123456789012345678"] };
  assert.equal(isTrustedAntiBot(antiBot, "123456789012345678"), true);
  assert.equal(isTrustedAntiBot(antiBot, "234567890123456789"), false);
  assert.equal(isTrustedAntiBot({}, "123456789012345678"), false);
});
