# Futaba Sakura — Bot de segurança para Discord

Projeto em Node.js + discord.js com painel administrativo unificado. O nome oficial do bot é **Futaba Sakura**. O painel no Discord tem identidade visual hacker inspirada na Futaba, enquanto avisos à equipe e mensagens do Anti-Bot são profissionais.

> Importante: este pacote é o código-fonte inicial do projeto. Ele não está conectado à sua conta, não cria uma aplicação no Discord Developer Portal e não foi implantado na hospedagem. É necessário configurar o aplicativo, permissões, variáveis de ambiente e testar no servidor antes de ativar punições automáticas.

## Requisitos

- Node.js **18.18.0 ou superior** (o projeto está fixado no discord.js 14.28.1).
- Uma aplicação e um bot criados no Discord Developer Portal.
- Uma hospedagem que mantenha o processo Node.js ativo e preserve a pasta `data/` entre reinícios.

O pacote discord.js 14.28.1 declara suporte a Node.js 18 ou superior. Consulte a versão instalada antes de atualizar a dependência: https://www.npmjs.com/package/discord.js

## Instalação

1. Envie todos os arquivos da pasta do projeto para a hospedagem.
2. Instale as dependências com `npm install`.
3. Copie `.env.example` para `.env` e preencha `DISCORD_TOKEN`, `CLIENT_ID` e `POOL_PARTY_GUILD_ID` com os valores reais. `GUILD_ID` não é utilizado. Para ativar a integração do site, configure também `API_PORT`, `FUTABA_API_SECRET` e `API_ALLOWED_GUILD_IDS` (este último precisa ser exatamente o mesmo ID do POOL PARTY). Para a Central de Apelações, configure também `PUBLIC_SITE_URL`; para enviar e-mails das apelações de banimento configure `APPEALS_EMAIL_API_KEY` e `APPEALS_EMAIL_FROM` (Resend).
4. No Developer Portal, habilite os intents privilegiados **Server Members Intent** e **Message Content Intent**. O bot também usa os eventos de moderação/audit log.
5. Convide o bot com os escopos `bot` e `applications.commands`.
6. Conceda somente as permissões necessárias para as funções que pretende ativar: View Channels, Read Message History, Send Messages, Embed Links, Manage Messages, Moderate Members, Manage Roles, Ban Members, Manage Guild e View Audit Log. A hierarquia do cargo da Futaba precisa ficar acima dos cargos que ela deve moderar.
7. Inicie com `npm start`.
8. No servidor, execute `/futaba painel`.

Não compartilhe o token do bot no chat, em prints ou no código. Guarde-o somente nas variáveis secretas da hospedagem.

## Configuração inicial recomendada

Por segurança, **todos os módulos começam desativados** em um servidor novo. Execute somente `/futaba painel`, selecione um módulo e abra as seções no menu interno. Configure canais, cargos, limites, textos, listas e ações antes de ativar cada módulo.

O painel inclui seções de visão geral, canais, detecção e limites, mensagens e banner, cargos e permissões e, quando aplicável, listas ou regras avançadas. Os menus de canais e cargos atualizam as seleções salvas; os formulários editam os parâmetros de cada módulo. As alterações são persistidas em `data/guilds.json`.

- Configure a senha do Anti-Bot pela seção Visão geral do Anti-Bot antes de ativá-lo.
- Configure canais monitorados, avisos públicos, logs e alertas em Canais.
- Configure cargos de alerta, cargos autorizados do Anti-Link e o cargo de quarentena do Anti-Bot em Cargos e permissões.
- Em **Anti-Bot → Listas**, adicione IDs de bots confiáveis. Eles são ignorados pelo Anti-Bot, sem quarentena, autenticação ou alertas de entrada desse módulo; os outros módulos continuam funcionando normalmente.
- Edite limites, ações automáticas, mensagens, banner, palavras proibidas, whitelist e blacklist dentro das seções correspondentes.
- Para os módulos Anti-Spam, Anti-Flood e Spam de Menções, atraso de exclusão `0` mantém as mensagens; valores de 1 a 3600 agendam a limpeza da janela. O padrão para novos servidores é 1 segundo. A Futaba precisa de `Gerenciar mensagens` e `Ler histórico de mensagens` no canal.
- Teste primeiro em um servidor privado, com limites conservadores e sem habilitar punições automáticas em seu servidor principal.

## Comando disponível

- `/futaba painel` — único comando de administração. Todas as configurações são feitas nos menus, seletores, botões e formulários dentro do painel. Os subcomandos administrativos antigos foram removidos do registro da aplicação.

Placeholders disponíveis nas mensagens: `{user}`, `{channel}`, `{type}`, `{action}` e `{content}`.

## Política de senha do Anti-Bot

- Primeira configuração: pede somente a nova senha e a confirmação.
- Trocas seguintes: pede senha atual, nova senha e confirmação.
- A senha precisa ter de 12 a 128 caracteres, com ao menos uma letra minúscula, uma maiúscula e um número.
- O banco guarda salt e hash derivados com scrypt; a senha original não é armazenada.
- A senha é enviada por modal privado do Discord, nunca em mensagem pública.
- Não existe botão de troca sem senha atual. Se a senha for perdida, a recuperação exige intervenção técnica no armazenamento local e deve ser tratada fora do painel.

## O que cada módulo faz

### Anti-Spam

Somente analisa canais selecionados. Detecta mensagens repetidas, spam de emojis e assinaturas repetidas de stickers/anexos. Quando a exclusão está ativada e o atraso é maior que zero, busca e apaga todas as mensagens enviadas pelo membro no canal durante a janela de repetição que terminou na mensagem detectada. Aplica timeout conforme a duração configurada, publica aviso com menção real ao membro, tenta DM e registra a infração.

### Anti-Flood

Somente analisa canais selecionados. Conta mensagens por membro, por canal e janela de tempo configurada. Quando a exclusão está ativada e o atraso é maior que zero, busca e apaga todas as mensagens enviadas pelo membro no canal dentro da janela que disparou a regra. Aplica timeout conforme a duração configurada. Não mistura as regras do Anti-Spam.

### Spam de Menções

Detecta menções excessivas (usuários, cargos, @everyone e @here) somadas dentro da janela configurável. Quando a exclusão está ativada e o atraso é maior que zero, busca e apaga todas as mensagens enviadas pelo membro no canal dentro da janela que disparou a regra. Aplica timeout conforme a duração configurada. Não funciona como detector genérico de spam.

### AutoMod

Compara termos normalizados sem diferenciar maiúsculas/minúsculas ou acentos e encontra o termo mesmo dentro de uma mensagem maior. Quando há um canal de alertas da equipe configurado na seção Canais do AutoMod, envia um alerta com membro, ID, canal, conteúdo, termo detectado e resultado da exclusão. A lista não tem limite total de 100 termos: use os botões **Adicionar palavras** e **Remover palavras** no painel para gerenciar lotes de até 4.000 caracteres por envio. Os lotes são mesclados à lista existente, sem substituir ou truncar termos já salvos.

### Anti-Bot

O painel também permite editar o título, descrição, cor e rodapé dos embeds de autenticação, os estados de sucesso/liberação/expiração e as respostas privadas de senha incorreta, prazo vencido e autenticação concluída. Os campos automáticos de identificação do bot, prazo e estado continuam presentes para não remover informações necessárias à segurança.

O módulo começa desativado até a senha ser configurada. Depois de ativado, cada bot que entrar é tratado como suspeito, exceto os IDs cadastrados na whitelist de bots confiáveis, configurada pela seção **Listas** do Anti-Bot. Bots confiáveis não passam por quarentena, autenticação, alertas de entrada nem bloqueios desse módulo. A whitelist é exclusiva do Anti-Bot; os outros módulos podem continuar analisando mensagens e eventos desses bots. A Futaba tenta identificar pelo audit log quem adicionou o bot e envia a essa pessoa a DM configurada, tenta remover cargos gerenciáveis, atribuir um cargo de quarentena, aplicar castigo de sete dias e inicia cinco minutos para autenticação. A API é chamada para aplicar o castigo; se o Discord recusar, a restrição por cargo/canais continua sendo usada como alternativa. Sem autenticação, o bot é banido quando a Futaba tem permissão. Tentativas registradas de remover ou encurtar o timeout, alterar cargos do bot isolado, ampliar as permissões do cargo de quarentena, conceder permissões diretamente ao bot por sobrescritas de canal ou desbanir um bot bloqueado provocam tentativas de banir o responsável e o bot. A Futaba diferencia concessões de permissão de alterações que apenas aumentam as restrições. Os alertas à equipe e os registros incluem o bot atingido, o executor identificado, o tipo de intervenção e o resultado de cada tentativa de banimento.

**Limitações:** a Futaba não consegue remover cargos acima do próprio cargo, garantir isolamento de canais com sobrescritas específicas que estejam fora do seu alcance, banir o proprietário do servidor nem ultrapassar permissões da plataforma. O evento de audit log precisa estar disponível e o bot precisa de View Audit Log e Ban Members. O cargo da Futaba também precisa estar acima do cargo do responsável e do bot. Um proprietário que fizer uma intervenção não poderá ser banido pelo bot; o incidente será registrado e o bot será novamente bloqueado quando possível. Se o Discord impedir um dos banimentos por permissão ou hierarquia, o alerta informa a falha em vez de afirmar que a punição foi concluída.

### Anti-Raid

Conta novas entradas por janela configurada. Ao ultrapassar o limite, eleva temporariamente o nível de verificação do servidor para Very High e avisa a equipe. Ao fim do período, tenta restaurar o nível anterior.

### Anti-Nuke

Acompanha eventos destrutivos de audit log. O padrão inicial exige uma sequência de três eventos monitorados do mesmo executor em doze segundos antes de tentar banir o responsável. Isso reduz punições por uma única alteração legítima. O proprietário do servidor não pode ser banido pela Futaba. A proteção depende de View Audit Log e Ban Members.

### Anti-Link

A ordem de decisão é: blacklist; whitelist de GIF/provedores confiáveis; whitelist geral; cargos autorizados; bloqueio padrão. A blacklist prevalece sobre cargos e whitelist. GIFs têm pré-configuração para Tenor e GIPHY, suas variações de mídia listadas e URLs terminadas em `.gif` ou `.gifv` (incluindo URLs com query/fragment). Os domínios confiáveis são:

- `tenor.com`, `media.tenor.com`, `c.tenor.com`
- `giphy.com`, `media.giphy.com`, `i.giphy.com`, `giphyusercontent.com`, `gph.is`
- extensões `.gif` e `.gifv`, em qualquer domínio, se a opção de whitelist de GIF estiver ativada

Whitelist libera o uso por qualquer membro, sem exigir cargo. Cargos autorizados podem enviar links fora da whitelist, mas nunca ignoram a blacklist.

**Limitação da análise de ameaça:** o módulo aplica as listas e regras locais; ele não consegue garantir que qualquer URL desconhecida seja segura ou maliciosa. Não trate a whitelist como garantia de segurança. A opção `gifWhitelistEnabled` pode ser ligada/desligada na seção **Palavras e links** do Anti-Link dentro do painel. A integração com um provedor externo de reputação/antiphishing ainda não está implementada nesta versão.

## Integração com o site (Netlify)

O bot pode iniciar uma API HTTP privada para o backend do site consultar e atualizar configurações por servidor. A API não substitui o processo persistente do Discord Gateway: o bot continua rodando na hospedagem atual, enquanto o site estático e as Netlify Functions ficam no Netlify.

Configure na hospedagem do bot (gere o segredo, por exemplo, com `openssl rand -hex 32`; nunca reutilize o token do Discord). Defina também `POOL_PARTY_GUILD_ID` com o ID real do servidor POOL PARTY; o processo sai automaticamente de qualquer outro servidor e não processa eventos fora do permitido:

- `API_PORT`: porta interna/pública disponibilizada pela hospedagem. Se ficar vazia, a API não inicia.
- `API_HOST`: normalmente `0.0.0.0` em hospedagens que exigem bind público.
- `FUTABA_API_SECRET`: segredo aleatório com pelo menos 32 caracteres.
- `API_ALLOWED_GUILD_IDS`: configure obrigatoriamente com o ID do POOL PARTY; IDs separados por vírgula são suportados, mas esta instalação deve conter somente o servidor oficial.

Rotas disponíveis:

- `GET /api/v1/health` — estado básico do processo, sem dados do servidor.
- `GET /api/v1/guilds/{guildId}/config` — consulta a configuração do servidor.
- `PATCH /api/v1/guilds/{guildId}/config` — atualiza um módulo usando `{ "module": "antiLink", "patch": { "whitelist": ["example.com"] } }`.
- `GET /api/v1/guilds/{guildId}/resources` — retorna somente os canais de texto e cargos disponíveis para preencher seletores do painel; não inclui membros nem dados privados.

Todas as rotas de configuração exigem `Authorization: Bearer <FUTABA_API_SECRET>`. O limite atual é de 120 requisições por IP a cada minuto. Disponibilize a API ao Netlify apenas por HTTPS (TLS da própria hospedagem ou proxy reverso); não publique a porta em HTTP aberto. A resposta para o site nunca inclui o hash/salt da senha Anti-Bot, dados de autenticação pendente ou a lista interna de bots bloqueados. A API valida os tipos e limites dos campos e recusa atualizações de campos internos.

**O segredo nunca pode ir para o JavaScript do navegador.** O site chama uma Netlify Function; essa função autentica o usuário com Discord OAuth2, consulta no Discord se ele tem permissão nativa Administrator no POOL PARTY e só então encaminha a alteração à API do bot usando variáveis secretas do Netlify. Não exponha a API diretamente ao navegador e não confie em IDs/permissões enviados pelo cliente.

Exemplo de leitura autenticada (executado somente no backend/Netlify Function):

```js
const response = await fetch(`${process.env.FUTABA_BOT_API_URL}/api/v1/guilds/${guildId}/config`, {
  headers: { Authorization: `Bearer ${process.env.FUTABA_API_SECRET}` }
});
if (!response.ok) throw new Error(`Futaba API: ${response.status}`);
const { config } = await response.json();
```

O frontend do site está na pasta `site/` (HTML/CSS/JavaScript estático + Netlify Functions). Ele autentica com Discord OAuth2, cria uma sessão criptografada em cookie `HttpOnly`, verifica no Discord a permissão nativa **Administrator** em cada operação e aceita somente o ID definido em `POOL_PARTY_GUILD_ID`. Não há assinatura, pagamento ou liberação para outros servidores.

### Publicar o site no Netlify

1. Faça deploy da pasta `site/` como diretório-base do projeto Netlify. O `netlify.toml` já aponta `public/` e `netlify/functions/`.
2. No Discord Developer Portal, adicione exatamente o valor de `DISCORD_REDIRECT_URI` à lista de Redirects OAuth2 da aplicação. Use os escopos `identify` e `guilds`.
3. Configure no Netlify as variáveis listadas em `site/.env.example`: `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `DISCORD_REDIRECT_URI`, `SESSION_SECRET`, `FUTABA_BOT_API_URL`, `FUTABA_API_SECRET` e `POOL_PARTY_GUILD_ID`.
4. Na hospedagem do bot, configure `POOL_PARTY_GUILD_ID`, `API_PORT`, `FUTABA_API_SECRET` (mesmo valor do Netlify) e `API_ALLOWED_GUILD_IDS` com o mesmo ID do POOL PARTY. Disponibilize a API somente por HTTPS.
5. O processo persistente do bot continua na hospedagem atual. Netlify hospeda apenas o site e suas funções; não substitua o processo Discord Gateway por funções serverless.

O painel permite editar os oito módulos, os canais e cargos de cada módulo, mensagens públicas e DMs, estilos de embeds de registro/alerta (autor, ícones HTTPS, título, descrição, cor, rodapé, imagem, miniatura, timestamp e campos adicionais), mensagens/estados da autenticação Anti-Bot e a whitelist de bots confiáveis. Em Configurações gerais, também é possível configurar o canal de punições e o embed Tribunal de Fontaine.

### Comandos de moderação manual

Os comandos com prefixo configurável (padrão `!`) são: `!ban`, `!unban`, `!kick`, `!mute`, `!unmute`, `!warn`, `!unwarn`, `!punições`, `!lock`, `!unlock` e `!clear`.

- `!ban @membro [motivo]`; `!unban ID [motivo]`; `!kick @membro [motivo]`.
- `!mute @membro [10m] [motivo]` aceita segundos (`30s`), minutos (`10m`), horas (`2h`) e dias (`7d`), com limite de 28 dias; sem duração, usa 10 minutos. `!unmute @membro` remove o timeout.
- `!warn @membro [motivo]`; `!unwarn @membro` remove a advertência ativa mais recente.
- `!punições @membro [página]` consulta o histórico persistente, incluindo data, moderador, motivo, duração e estado.
- `!lock` e `!unlock` bloqueiam/restauram o canal atual, guardando os overwrites anteriores e preservando acesso dos cargos com Gerenciar mensagens/Administrador e da Futaba.
- `!clear 50`, `!clear 50 @membro` e `!clear @membro` limpam até 1.000 mensagens. Mensagens com menos de 14 dias são apagadas em lotes; as mais antigas são tentadas individualmente.

As permissões do executor são verificadas por comando. A hierarquia e as permissões efetivas do Discord ainda se aplicam. O histórico fica no diretório `data/` junto às configurações e não é enviado ao site. Configure um canal em Configurações gerais → Canal de punições para receber os embeds de ação.

## Central de Apelações — ativação segura

A Central começa desativada em uma instalação nova. Depois de publicar o site e o bot, entre no painel administrativo do site, abra **Configurar Central**, selecione o canal de alertas, atribua os cargos de visualizar/assumir/decidir/gerenciar e marque **Central de Apelações ativa**. Faça primeiro um teste controlado antes de divulgar o link aos membros.

## Persistência e dados

As configurações são salvas em `data/guilds.json`. Os dados da Central de Apelações (solicitações, conversas, evidências, perfis e auditoria) ficam em `data/appeals.json`. Preserve a pasta `data/` ao atualizar/reiniciar a hospedagem. Faça cópias de segurança regulares. Não apague `data/` ao atualizar o código.

## Testes automatizados e antes de produção

Execute `npm run check` e `npm test` para validar a sintaxe e os testes automatizados do bot. Os testes do backend OAuth/Netlify ficam no pacote separado do site e podem ser executados com `npm test` dentro da pasta do site. Isso não substitui um teste real com um bot Discord configurado.

- Crie um servidor de teste.
- Configure somente um canal de teste para Anti-Spam, Anti-Flood, menções, AutoMod e Anti-Link.
- Configure avisos/logs/alertas separados e verifique as menções.
- Teste a senha Anti-Bot com um bot de teste que você controla.
- Confirme a hierarquia do cargo da Futaba antes de habilitar banimentos automáticos.
- Teste Anti-Raid e Anti-Nuke em servidor isolado; mantenha limites conservadores.

## Segurança e limites

- Todos os módulos começam desativados; ative-os somente depois de configurar e testar.
- A Futaba não pode banir o dono do servidor nem atuar acima da própria hierarquia/permissões.
- As decisões de anti-nuke são heurísticas por contagem e janela; não existe detecção perfeita sem calibrar os limites para a atividade normal do servidor.
- O sistema não executa restauração automática completa de canais/cargos excluídos nesta versão. Preserve backups separados do servidor.
- O projeto não contém token, senha padrão nem acesso à sua hospedagem.

## Observações sobre a configuração da senha

O botão **Senha Anti-Bot** do painel abre o formulário de configuração. Na primeira vez, ele solicita apenas nova senha e confirmação. Depois que existe um hash salvo, toda alteração exige a senha atual, além da nova senha e confirmação. Uma senha atual incorreta cancela a alteração sem substituir o registro.

### Anti-Spam, Anti-Flood e Spam de Menções

Na seção **Punições e exclusão**, cada módulo possui configurações independentes para duração do timeout, atraso para apagar as mensagens do membro e atraso para apagar o aviso público. Defina `0` para desativar o timeout ou manter a mensagem correspondente. O timeout exige a permissão **Moderar membros** e que o cargo da Futaba esteja acima do membro na hierarquia.



## Central de Apelações (site)

A API privada inclui rotas de elegibilidade, criação/listagem/detalhe, mensagens persistentes, atribuição exclusiva, transferência, estados/decisões, convite ao membro, perfis personalizados e notas internas. A interface do site é servida por `/appeals.html` e `/appeals-staff.html`; as funções Netlify verificam a sessão OAuth e encaminham a identidade validada pelo canal privado.

Configure no site, em **Configurações gerais → Configurar Central**, os cargos de visualização, assumir, decidir e gerenciar, além do canal de alertas. A permissão de cada operação é verificada novamente no backend. O primeiro atendente que assumir define o responsável; tentativas concorrentes recebem conflito e não substituem a atribuição existente.

Os dados das apelações são gravados separadamente em `data/appeals.json` com escrita atômica. A hospedagem precisa preservar esse arquivo entre reinícios e deploys. Imagens e mensagens são limitadas e validadas antes de serem armazenadas. Nunca coloque a chave Resend ou o segredo da API no frontend.
