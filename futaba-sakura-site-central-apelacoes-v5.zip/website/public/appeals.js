const root = document.querySelector("#appeals-root");
const mode = document.body.dataset.appealsMode;
const qs = new URLSearchParams(location.search);
let me = null;
let eligibility = null;
let selectedAppealId = qs.get("id") || null;
let currentAppeal = null;
let staffList = [];
let staffPermissions = {};
let profile = {};
let poller = null;
const statuses = {
  pending: "Pendente", in_analysis: "Em análise", waiting_member: "Aguardando membro",
  waiting_staff: "Aguardando staff", accepted: "Aceita", rejected: "Rejeitada", closed: "Encerrada"
};
const reasonNames = { ban: "Banimento", warn: "Advertência (Warn)", mute: "Silenciamento (Mute)" };
const $ = (s, parent = document) => parent.querySelector(s);
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
const avatar = (user, fallback = "F") => {
  const raw = user?.avatarUrl || user?.avatar || "";
  const id = user?.id || user?.userId || "";
  const hash = user?.avatarHash || (raw && !/^https:\/\//i.test(raw) ? raw : "");
  const url = /^https:\/\//i.test(raw) ? raw : (id && hash ? `https://cdn.discordapp.com/avatars/${encodeURIComponent(id)}/${encodeURIComponent(hash)}.png?size=96` : "");
  return url ? `<img class="ap-avatar" src="${esc(url)}" alt="" referrerpolicy="no-referrer"/>` : `<span class="ap-avatar ap-avatar-fallback">${esc((user?.displayName || user?.globalName || user?.username || fallback).slice(0,1).toUpperCase())}</span>`;
};
function showToast(message, error = false) {
  const el = $("#appeals-toast"); el.textContent = message; el.classList.toggle("error", error); el.classList.add("visible");
  clearTimeout(showToast.timer); showToast.timer = setTimeout(() => el.classList.remove("visible"), 4500);
}
async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { ...(options.body ? { "content-type": "application/json" } : {}), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Falha de comunicação (${response.status}).`);
  return data;
}
function loginUrl(next) { return `/.netlify/functions/auth-start?next=${encodeURIComponent(next)}`; }
function time(value) {
  if (!value) return "—";
  try { return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(new Date(value)); }
  catch { return value; }
}
function statusPill(status) { return `<span class="ap-status ap-status-${esc(status)}">${esc(statuses[status] || status)}</span>`; }
function header(title, subtitle) {
  const name = me?.globalName || me?.username || "Conta Discord";
  return `<header class="ap-topbar"><a class="ap-brand" href="/"><span class="ap-brand-mark">✦</span><span><b>FUTABA SAKURA</b><small>POOL PARTY • CENTRAL DE ATENDIMENTO</small></span></a><div class="ap-user">${avatar({ id: me?.id, avatarHash: me?.avatar, globalName: name })}<span>${esc(name)}</span><button class="ap-logout" id="ap-logout">Sair</button></div></header><section class="ap-page-heading"><div><div class="ap-kicker">POOL PARTY <b>/</b> ${mode === "staff" ? "ALTA STAFF" : "ATENDIMENTO AO MEMBRO"}</div><h1>${title}</h1><p>${subtitle}</p></div><a class="ap-back" href="/">← Voltar ao site</a></section>`;
}
function bindLogout() {
  const btn = $("#ap-logout");
  btn?.addEventListener("click", async () => { await api("/api/auth/logout", { method: "POST" }).catch(() => null); location.href = "/"; });
}
function loginScreen(staff = false) {
  const title = staff ? "Atendimento da alta staff" : "Central de Apelações";
  const desc = staff ? "Entre com sua conta Discord. A Futaba verificará seus cargos e permissões antes de liberar a fila." : "Entre com sua conta Discord para abrir uma apelação ou acompanhar suas solicitações.";
  const ticket = /^FUT-[A-F0-9]{8}$/.test(qs.get("id") || "") ? `?id=${encodeURIComponent(qs.get("id"))}` : "";
  const next = `${staff ? "/appeals-staff.html" : "/appeals.html"}${ticket}`;
  root.innerHTML = `<div class="ap-login-wrap"><div class="ap-login-art"><span class="ap-kicker">PHANTOM THIEVES • POOL PARTY</span><div class="ap-large-mark">F</div><h1>${title}</h1><p>${desc}</p><a class="ap-primary" href="${loginUrl(next)}">◉ Entrar com Discord</a><a class="ap-secondary" href="/">Voltar à página inicial</a></div></div>`;
}
function renderAttachment(a) {
  const data = a.data || "";
  return `<a class="ap-attachment" href="${esc(data)}" target="_blank" rel="noopener noreferrer"><img src="${esc(data)}" alt="${esc(a.name)}"/><span>${esc(a.name)}</span></a>`;
}
function renderEvidence(appeal) {
  const images = appeal.attachments || [];
  const links = appeal.links || [];
  return `${images.length ? `<div class="ap-evidence-grid">${images.map(renderAttachment).join("")}</div>` : `<p class="ap-muted">Nenhuma imagem anexada.</p>`}${links.length ? `<div class="ap-link-list">${links.map(link => `<a href="${esc(link)}" target="_blank" rel="noopener noreferrer">↗ ${esc(link)}</a>`).join("")}</div>` : ""}`;
}
async function loadMember() {
  const data = await api("/api/appeals?action=eligibility");
  eligibility = data;
  const list = await api("/api/appeals?action=list&view=member");
  staffPermissions = list.permissions || {};
  renderMemberHome(list.appeals || []);
  if (selectedAppealId && /^FUT-[A-F0-9]{8}$/.test(selectedAppealId)) await openMemberAppeal(selectedAppealId);
}
function renderMemberHome(appeals) {
  const centralActive = eligibility.active !== false;
  const canBan = centralActive && eligibility.isBanned;
  const canMember = centralActive && eligibility.isMember;
  const options = `${canBan ? `<option value="ban">Banimento</option>` : ""}${canMember ? `<option value="warn">Advertência (Warn)</option><option value="mute">Silenciamento (Mute)</option>` : ""}`;
  const isStaff = eligibility.isStaff;
  root.innerHTML = `${header("Central de Apelações", "Abra uma solicitação e acompanhe toda a conversa com a alta staff em um só lugar.")}
    <div class="ap-layout ap-member-layout">
      <section class="ap-main-column">
        <div class="ap-welcome-card"><div><span class="ap-kicker">SEU ESPAÇO DE ATENDIMENTO</span><h2>Olá, ${esc(me.globalName || me.username)}.</h2><small class="ap-user-id">ID Discord: ${esc(me.id)}</small><p>${!centralActive ? "A Central está temporariamente fechada para novas apelações. Você ainda pode consultar solicitações anteriores e continuar conversas em andamento." : canBan ? "Identificamos que sua conta está banida do POOL PARTY. Para apelar, informe um e-mail válido para receber convites e atualizações." : canMember ? "Você pode abrir uma apelação de advertência ou silenciamento. Mantenha as mensagens diretas do servidor habilitadas durante o atendimento." : "Não foi possível identificar uma situação elegível para abrir apelação. Caso acredite que isso está incorreto, fale com a administração do POOL PARTY."}</p></div><span class="ap-welcome-symbol">✦</span></div>
        ${appeals.length ? `<section class="ap-card"><div class="ap-card-head"><div><h2>Minhas apelações</h2><p>Acompanhe o estado e retome suas conversas.</p></div><span class="ap-count">${appeals.length}</span></div><div class="ap-appeal-list">${appeals.map(item => `<button class="ap-appeal-row" data-open-appeal="${esc(item.id)}"><span class="ap-row-code">${esc(item.id)}</span><span class="ap-row-copy"><b>${esc(reasonNames[item.reason] || item.reason)}</b><small>Atualizada em ${time(item.updatedAt)}</small></span>${statusPill(item.status)}${item.unreadForMember ? `<i class="ap-unread-dot" title="Nova mensagem"></i>` : ""}<span class="ap-row-arrow">↗</span></button>`).join("")}</div></section>` : `<section class="ap-card ap-empty"><span class="ap-empty-icon">▤</span><h2>Nenhuma apelação por enquanto</h2><p>Quando você enviar uma solicitação, ela aparecerá aqui com o histórico do atendimento.</p></section>`}
        ${isStaff ? `<a class="ap-staff-shortcut" href="/appeals-staff.html">✦ Você também tem acesso à área da equipe — abrir Central da Alta Staff ↗</a>` : ""}
      </section>
      <aside class="ap-side-column"><form id="ap-new-form" class="ap-card ap-form-card"><div class="ap-card-head"><div><h2>Abrir apelação</h2><p>Preencha as informações com clareza.</p></div><span class="ap-new-icon">＋</span></div>
        ${options ? `<div class="ap-field"><label for="ap-reason">Motivo da apelação</label><select id="ap-reason" name="reason" required>${options}</select></div>` : `<div class="ap-warning">${!centralActive ? "A abertura de novas apelações está temporariamente suspensa." : "Sua conta não foi identificada como banida nem como membro atual. A abertura de apelações está indisponível."}</div>`}
        ${canBan ? `<div class="ap-info-note">Para apelações de banimento, a Futaba pode não conseguir enviar mensagens pelo Discord. Seu endereço de e-mail será usado para convites ao chat, pedidos de informações e atualizações da decisão.</div>` : ""}
        <div class="ap-field ap-email-field" hidden><label for="ap-email">Endereço de e-mail</label><input id="ap-email" type="email" name="email" autocomplete="email" placeholder="voce@exemplo.com"/><small>Informe um endereço que você consiga acessar.</small></div>
        <div class="ap-field ap-dm-field" hidden><label class="ap-check"><input id="ap-dm" name="dmAllowed" type="checkbox"/><span>Confirmo que as mensagens diretas de membros do POOL PARTY estão habilitadas e permanecerão habilitadas durante a apelação.</span></label></div>
        <div class="ap-field"><label for="ap-description">Descrição</label><textarea id="ap-description" name="description" rows="6" minlength="20" maxlength="5000" placeholder="Explique o que aconteceu e por que deseja recorrer..." required></textarea><small>De 20 a 5.000 caracteres. Seja respeitoso e inclua informações relevantes.</small></div>
        <div class="ap-field"><label for="ap-images">Evidências em imagem (máximo 8)</label><input id="ap-images" type="file" accept="image/png,image/jpeg,image/webp,image/gif" multiple/><small>Cada imagem pode ter até 600 KB; limite total de 3 MB. PNG, JPG, WEBP ou GIF.</small><div id="ap-file-list" class="ap-file-list"></div></div>
        <div class="ap-field"><label for="ap-links">Links opcionais</label><textarea id="ap-links" rows="2" placeholder="https://... (um link por linha)"></textarea><small>Links HTTPS para imagens, vídeos ou outras evidências.</small></div>
        <button class="ap-primary ap-submit" type="submit" ${options ? "" : "disabled"}>Enviar apelação <span>↗</span></button><p class="ap-privacy-note">Seus dados e evidências ficam disponíveis apenas para você e para a equipe autorizada.</p>
      </form></aside>
    </div>`;
  bindLogout();
  root.querySelectorAll("[data-open-appeal]").forEach(button => button.addEventListener("click", () => openMemberAppeal(button.dataset.openAppeal)));
  const reason = $("#ap-reason");
  if (reason) {
    const updateConditional = () => {
      const ban = reason.value === "ban";
      $(".ap-email-field").hidden = !ban;
      $(".ap-dm-field").hidden = ban;
      $("#ap-email").required = ban;
      $("#ap-dm").required = !ban;
    };
    reason.addEventListener("change", updateConditional); updateConditional();
  }
  const imagesInput = $("#ap-images");
  imagesInput?.addEventListener("change", () => {
    const files = Array.from(imagesInput.files || []);
    const bytes = files.reduce((total, f) => total + f.size, 0);
    if (files.length > 8 || files.some(f => f.size > 600 * 1024) || bytes > 3 * 1024 * 1024) {
      imagesInput.value = ""; $("#ap-file-list").textContent = "Seleção inválida: máximo de 8 imagens, 600 KB por imagem e 3 MB no total."; return;
    }
    $("#ap-file-list").textContent = files.length ? files.map(f => `${f.name} (${Math.ceil(f.size / 1024)} KB)`).join(" • ") : "";
  });
  $("#ap-new-form")?.addEventListener("submit", submitMemberAppeal);
}
async function readFiles(input, maxCount = 8, maxTotalBytes = 3 * 1024 * 1024) {
  const files = Array.from(input.files || []);
  if (files.length > maxCount) throw new Error(`Selecione no máximo ${maxCount} imagens.`);
  let total = 0;
  return Promise.all(files.map(file => new Promise((resolve, reject) => {
    total += file.size;
    if (file.size > 600 * 1024 || total > maxTotalBytes) return reject(new Error(`As imagens excedem o limite de ${Math.round(maxTotalBytes / 1024)} KB permitido.`));
    if (!file.type.startsWith("image/") || !["image/jpeg","image/png","image/webp","image/gif"].includes(file.type)) return reject(new Error("Formato de imagem não permitido."));
    const reader = new FileReader(); reader.onload = () => resolve({ name: file.name, mimeType: file.type, data: reader.result }); reader.onerror = () => reject(new Error(`Não foi possível ler ${file.name}.`)); reader.readAsDataURL(file);
  })));
}
async function submitMemberAppeal(event) {
  event.preventDefault();
  const form = event.currentTarget; const button = form.querySelector("button[type=submit]");
  const reason = form.elements.reason.value;
  const dmAllowed = Boolean(form.elements.dmAllowed?.checked);
  if (reason !== "ban" && !dmAllowed) return showToast("Confirme que suas mensagens diretas estão habilitadas.", true);
  button.disabled = true; button.textContent = "Enviando...";
  try {
    const payload = { action: "create", reason, description: form.elements.description.value, email: form.elements.email?.value || "", dmAllowed, links: $("#ap-links").value.split(/\r?\n/).map(x => x.trim()).filter(Boolean), attachments: await readFiles($("#ap-images")) };
    const data = await api("/api/appeals", { method: "POST", body: JSON.stringify(payload) });
    showToast(data.message || "Apelação enviada.");
    const list = await api("/api/appeals?action=list&view=member"); renderMemberHome(list.appeals || []);
    setTimeout(() => openMemberAppeal(data.appeal.id), 250);
  } catch (error) { showToast(error.message, true); button.disabled = false; button.innerHTML = 'Enviar apelação <span>↗</span>'; }
}
async function openMemberAppeal(id) {
  selectedAppealId = id;
  try {
    const data = await api(`/api/appeals?action=detail&id=${encodeURIComponent(id)}`);
    currentAppeal = data.appeal;
    renderMemberDetail(data);
  } catch (error) { showToast(error.message, true); }
}
function renderMessages(appeal, staffView = false) {
  const messages = appeal.messages || [];
  return messages.length ? messages.map(message => `<article class="ap-message ${message.senderType === "staff" ? "from-staff" : message.senderType === "system" ? "from-system" : "from-member"}"><div class="ap-message-head">${avatar({ id: message.senderId, avatar: message.senderAvatar, globalName: message.senderName })}<b>${esc(message.senderName)}</b><span>${message.senderType === "staff" ? "ALTA STAFF" : message.senderType === "system" ? "SISTEMA" : "MEMBRO"}</span><time>${time(message.at)}</time></div><div class="ap-message-content">${esc(message.content).replace(/\n/g,"<br>")}</div>${message.attachments?.length ? `<div class="ap-evidence-grid ap-chat-files">${message.attachments.map(renderAttachment).join("")}</div>` : ""}</article>`).join("") : `<div class="ap-chat-empty">A conversa ainda não começou. A alta staff poderá enviar uma mensagem por aqui.</div>`;
}
function renderMemberDetail(data) {
  const appeal = data.appeal; const assigned = data.assignedProfile || appeal.assignedProfile;
  root.innerHTML = `${header(`Apelação ${esc(appeal.id)}`, "Acompanhe o estado e converse com a alta staff responsável.")}
    <div class="ap-detail-layout"><section class="ap-main-column">
      <div class="ap-detail-toolbar"><button class="ap-back-button" id="ap-back-list">← Minhas apelações</button>${statusPill(appeal.status)}</div>
      <section class="ap-card"><div class="ap-card-head"><div><h2>Informações da solicitação</h2><p>Enviada em ${time(appeal.createdAt)}</p></div><span class="ap-code-chip">${esc(appeal.id)}</span></div><div class="ap-detail-grid"><div><small>Motivo</small><b>${esc(reasonNames[appeal.reason] || appeal.reason)}</b></div><div><small>Estado da apelação</small><b>${esc(statuses[appeal.status] || appeal.status)}</b></div></div><div class="ap-description-block"><small>Descrição enviada</small><p>${esc(appeal.description).replace(/\n/g,"<br>")}</p></div><div class="ap-description-block"><small>Evidências</small>${renderEvidence(appeal)}</div></section>
      ${appeal.decision ? `<section class="ap-card ap-decision-card"><div class="ap-card-head"><div><h2>Decisão da alta staff</h2><p>${appeal.decision.status === "accepted" ? "Apelação aceita" : "Apelação rejeitada"} • ${time(appeal.decision.at)}</p></div>${statusPill(appeal.decision.status)}</div><p>${esc(appeal.decision.justification).replace(/\n/g,"<br>")}</p><small>Decisão registrada por ${esc(appeal.decision.byName || "Alta staff")}</small></section>` : ""}
      <section class="ap-card ap-chat-card"><div class="ap-card-head"><div><h2>Conversar com a alta staff</h2><p>As mensagens ficam salvas no histórico desta apelação.</p></div><span class="ap-live-indicator">ATENDIMENTO PRIVADO</span></div><div id="ap-chat-log" class="ap-chat-log">${renderMessages(appeal)}</div>${["accepted","rejected","closed"].includes(appeal.status) ? `<div class="ap-warning">Este atendimento foi finalizado. A conversa permanece disponível para consulta.</div>` : `<form id="ap-chat-form" class="ap-chat-form"><textarea name="content" rows="3" maxlength="4000" placeholder="Escreva uma mensagem para a alta staff..."></textarea><div class="ap-chat-actions"><label class="ap-file-button">＋ Evidências<input type="file" id="ap-chat-files" multiple accept="image/png,image/jpeg,image/webp,image/gif" hidden/></label><span id="ap-chat-file-label" class="ap-muted"></span><button class="ap-primary" type="submit">Enviar mensagem ↗</button></div></form>`}</section>
    </section><aside class="ap-side-column"><section class="ap-card ap-assignee-card"><div class="ap-card-head"><div><h2>Responsável pelo atendimento</h2><p>Membro da alta staff que assumiu sua apelação.</p></div></div>${assigned ? `<div class="ap-staff-profile" style="--profile-accent:${esc(assigned.color || "#ef1748")}">${avatar({ userId: assigned.userId, avatar: assigned.avatarUrl, displayName: assigned.displayName })}<div><b>${esc(assigned.displayName || "Atendente")}</b><small>${esc(assigned.description || "Alta staff do POOL PARTY")}</small></div></div>` : `<div class="ap-no-assignee">Ninguém assumiu esta apelação ainda.</div>`}</section><section class="ap-card ap-status-card"><h3>Estado da apelação</h3>${statusPill(appeal.status)}<p>${appeal.status === "waiting_member" ? "A equipe está aguardando informações suas." : appeal.status === "waiting_staff" ? "Sua mensagem foi recebida. A equipe continuará o atendimento." : appeal.status === "accepted" ? "Sua apelação foi aceita." : appeal.status === "rejected" ? "Sua apelação foi rejeitada." : "Sua apelação está em análise. Por favor, tenha paciência."}</p></section></aside></div>`;
  bindLogout();
  $("#ap-back-list").addEventListener("click", loadMember);
  $("#ap-chat-form")?.addEventListener("submit", sendMessage);
  $("#ap-chat-files")?.addEventListener("change", event => { $("#ap-chat-file-label").textContent = `${event.target.files.length} arquivo(s)`; });
  if (poller) clearInterval(poller); poller = setInterval(() => refreshChat("member"), 12000);
}
async function sendMessage(event) {
  event.preventDefault(); const form = event.currentTarget; const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  try {
    const attachments = await readFiles($("#ap-chat-files"), 4, 2 * 1024 * 1024);
    const sent = await api("/api/appeals", { method: "POST", body: JSON.stringify({ action: "message", appealId: selectedAppealId, content: form.elements.content.value, attachments }) });
    if (sent.delivery && !sent.delivery.delivered) showToast("Mensagem salva no atendimento. A notificação da equipe não foi entregue; a equipe poderá consultar a conversa no painel.", true);
    const data = await api(`/api/appeals?action=detail&id=${encodeURIComponent(selectedAppealId)}`); renderMemberDetail(data);
  } catch (error) { showToast(error.message, true); button.disabled = false; }
}
async function refreshChat(view) {
  if (!selectedAppealId || document.hidden) return;
  try {
    const data = await api(`/api/appeals?action=detail&id=${encodeURIComponent(selectedAppealId)}`);
    const currentLog = $("#ap-chat-log");
    const messagesChanged = data.appeal.messages?.length !== currentAppeal?.messages?.length;
    const statusChanged = data.appeal.status !== currentAppeal?.status;
    if (messagesChanged && currentLog) {
      currentLog.innerHTML = renderMessages(data.appeal, view); currentLog.scrollTop = currentLog.scrollHeight;
    }
    currentAppeal = data.appeal;
    if (statusChanged) {
      if (view === "staff") await openStaffAppeal(selectedAppealId);
      else await openMemberAppeal(selectedAppealId);
    }
  } catch { /* sessão ou conexão pode oscilar; a próxima atualização tentará novamente */ }
}

async function loadStaff() {
  const [list, p] = await Promise.all([api("/api/appeals?action=list&view=staff"), api("/api/appeals?action=profile")]);
  staffList = list.appeals || []; staffPermissions = list.permissions || {}; profile = p.profile || {};
  renderStaffHome();
  if (selectedAppealId) await openStaffAppeal(selectedAppealId);
}
function staffStat(label, value) { return `<div class="ap-stat"><strong>${value}</strong><small>${label}</small></div>`; }
function renderStaffHome() {
  const pending = staffList.filter(a => a.status === "pending").length;
  const inProgress = staffList.filter(a => a.status === "in_analysis").length;
  const waiting = staffList.filter(a => a.status === "waiting_member").length;
  const waitingStaff = staffList.filter(a => a.status === "waiting_staff").length;
  const accepted = staffList.filter(a => a.status === "accepted").length;
  const rejected = staffList.filter(a => a.status === "rejected").length;
  const decided = staffList.filter(a => ["accepted","rejected"].includes(a.status) && a.decisionAt);
  const averageSeconds = decided.length ? decided.reduce((sum, item) => sum + Math.max(0, (new Date(item.decisionAt) - new Date(item.createdAt)) / 1000), 0) / decided.length : null;
  const averageLabel = averageSeconds === null ? "—" : averageSeconds < 3600 ? `${Math.round(averageSeconds / 60)} min` : averageSeconds < 86400 ? `${(averageSeconds / 3600).toFixed(1)} h` : `${(averageSeconds / 86400).toFixed(1)} dias`;
  root.innerHTML = `${header("Central de Apelações", "Fila de atendimento da alta staff • POOL PARTY")}
    <div class="ap-staff-stats" id="ap-staff-stats">${staffStat("Total recebidas",staffList.length)}${staffStat("Pendentes",pending)}${staffStat("Em análise",inProgress)}${staffStat("Aguardando membro",waiting)}${staffStat("Aguardando staff",waitingStaff)}${staffStat("Aceitas",accepted)}${staffStat("Rejeitadas",rejected)}${staffStat("Tempo médio até decisão",averageLabel)}</div>
    <div class="ap-staff-layout"><section class="ap-card ap-queue-card"><div class="ap-card-head"><div><h2>Fila de apelações</h2><p>Selecione uma solicitação para abrir o atendimento.</p></div><button class="ap-secondary-button" id="ap-refresh">↻ Atualizar</button></div><div class="ap-filter-row"><input id="ap-search" type="search" placeholder="Buscar por ID, membro ou usuário"/><select id="ap-status-filter"><option value="">Todos os estados</option>${Object.entries(statuses).map(([key,val])=>`<option value="${key}">${val}</option>`).join("")}</select><select id="ap-assignment-filter"><option value="all">Todas as apelações</option><option value="mine">Meus atendimentos</option><option value="unassigned">Sem responsável</option><option value="waiting">Aguardando membro</option><option value="unread">Com mensagens novas</option></select></div><div id="ap-queue-list" class="ap-queue-list">${staffList.length ? staffList.map(renderQueueItem).join("") : `<div class="ap-chat-empty">Nenhuma apelação foi recebida ainda.</div>`}</div></section>
    <aside class="ap-card ap-profile-editor"><div class="ap-card-head"><div><h2>Seu perfil de atendente</h2><p>Vinculado à sua conta Discord.</p></div></div><form id="ap-profile-form"><label>Nome de exibição<input name="displayName" maxlength="40" value="${esc(profile.displayName || me.globalName || me.username)}"/></label><label>Descrição<textarea name="description" maxlength="180" rows="3">${esc(profile.description || "")}</textarea></label><label>Avatar (URL HTTPS)<input name="avatarUrl" type="url" value="${esc(profile.avatarUrl || "")}" placeholder="https://..."/></label><label>Cor de identificação<input name="color" type="color" value="${esc(profile.color || "#ef1748")}"/></label><button class="ap-primary" type="submit">Salvar perfil</button></form><p class="ap-privacy-note">Personalização visual não altera suas permissões.</p></aside></div>`;
  bindLogout();
  $("#ap-refresh").addEventListener("click", reloadStaffList);
  $("#ap-search").addEventListener("input", filterQueue);
  $("#ap-status-filter").addEventListener("change", filterQueue);
  $("#ap-assignment-filter").addEventListener("change", filterQueue);
  $("#ap-profile-form").addEventListener("submit", saveProfile);
  root.querySelectorAll("[data-open-staff]").forEach(button => button.addEventListener("click", () => openStaffAppeal(button.dataset.openStaff)));
  if (poller) clearInterval(poller);
  poller = setInterval(refreshStaffQueue, 15000);
}
async function refreshStaffQueue() {
  if (document.hidden || !$("#ap-queue-list")) return;
  try {
    const data = await api("/api/appeals?action=list&view=staff");
    staffList = data.appeals || []; staffPermissions = data.permissions || {};
    const counts = {
      pending: staffList.filter(a => a.status === "pending").length,
      inProgress: staffList.filter(a => a.status === "in_analysis").length,
      waiting: staffList.filter(a => a.status === "waiting_member").length,
      waitingStaff: staffList.filter(a => a.status === "waiting_staff").length,
      accepted: staffList.filter(a => a.status === "accepted").length,
      rejected: staffList.filter(a => a.status === "rejected").length
    };
    const decided = staffList.filter(a => ["accepted", "rejected"].includes(a.status) && a.decisionAt);
    const average = decided.length ? decided.reduce((sum, item) => sum + Math.max(0, (new Date(item.decisionAt) - new Date(item.createdAt)) / 1000), 0) / decided.length : null;
    const averageLabel = average === null ? "—" : average < 3600 ? `${Math.round(average / 60)} min` : average < 86400 ? `${(average / 3600).toFixed(1)} h` : `${(average / 86400).toFixed(1)} dias`;
    const stats = $("#ap-staff-stats");
    if (stats) stats.innerHTML = `${staffStat("Total recebidas", staffList.length)}${staffStat("Pendentes", counts.pending)}${staffStat("Em análise", counts.inProgress)}${staffStat("Aguardando membro", counts.waiting)}${staffStat("Aguardando staff", counts.waitingStaff)}${staffStat("Aceitas", counts.accepted)}${staffStat("Rejeitadas", counts.rejected)}${staffStat("Tempo médio até decisão", averageLabel)}`;
    filterQueue();
  } catch { /* a próxima atualização automática tentará novamente */ }
}
function renderQueueItem(item) {
  const active = item.id === selectedAppealId ? " selected" : "";
  return `<button class="ap-queue-item${active}" data-open-staff="${esc(item.id)}"><span class="ap-queue-avatar">${esc((item.memberName || "M").slice(0,1).toUpperCase())}</span><span class="ap-queue-copy"><b>${esc(item.memberName)}</b><small>${esc(item.id)} • ${esc(reasonNames[item.reason] || item.reason)} • ${time(item.createdAt)}</small></span>${statusPill(item.status)}${item.unreadForStaff ? `<i class="ap-unread-dot" title="Nova mensagem"></i>` : ""}</button>`;
}
function filterQueue() {
  const q = $("#ap-search").value.toLowerCase(); const status = $("#ap-status-filter").value; const scope = $("#ap-assignment-filter").value;
  const items = staffList.filter(item => (!status || item.status === status) && (!q || `${item.id} ${item.memberName} ${item.ownerId}`.toLowerCase().includes(q)) && (scope === "all" || (scope === "mine" && item.assignedTo === me.id) || (scope === "unassigned" && !item.assignedTo) || (scope === "waiting" && item.status === "waiting_member") || (scope === "unread" && item.unreadForStaff)));
  $("#ap-queue-list").innerHTML = items.length ? items.map(renderQueueItem).join("") : `<div class="ap-chat-empty">Nenhum resultado com esses filtros.</div>`;
  root.querySelectorAll("[data-open-staff]").forEach(button => button.addEventListener("click", () => openStaffAppeal(button.dataset.openStaff)));
}
async function reloadStaffList() {
  try { const data = await api("/api/appeals?action=list&view=staff"); staffList = data.appeals || []; staffPermissions = data.permissions || {}; renderStaffHome(); showToast("Fila atualizada."); }
  catch (error) { showToast(error.message, true); }
}
async function openStaffAppeal(id) {
  selectedAppealId = id;
  try { const data = await api(`/api/appeals?action=detail&id=${encodeURIComponent(id)}`); currentAppeal = data.appeal; renderStaffDetail(data); }
  catch (error) { showToast(error.message, true); }
}
function renderStaffDetail(data) {
  const appeal = data.appeal; const perms = data.permissions || staffPermissions; const assigned = appeal.assignedProfile;
  const isOwner = appeal.assignedTo === me.id;
  const canChat = !["accepted","rejected","closed"].includes(appeal.status) && (isOwner || perms.canManage);
  const canInternalNote = isOwner || perms.canManage;
  const canCall = isOwner || perms.canManage;
  const canChangeStatus = perms.canManage || (isOwner && perms.canDecide);
  root.innerHTML = `${header(`Atendimento ${esc(appeal.id)}`, "Análise individual • histórico e comunicação da solicitação")}
    <div class="ap-detail-toolbar"><button class="ap-back-button" id="ap-back-queue">← Voltar à fila</button>${statusPill(appeal.status)}<span class="ap-code-chip">${esc(appeal.id)}</span></div>
    <div class="ap-staff-detail-grid"><section class="ap-main-column">
      <section class="ap-card"><div class="ap-card-head"><div><h2>Dados do membro</h2><p>Identificação e conteúdo enviados na abertura.</p></div></div><div class="ap-member-banner">${avatar({ userId: appeal.ownerId, avatar: appeal.memberAvatar, globalName: appeal.memberName })}<div><b>${esc(appeal.memberName)}</b><small>ID: ${esc(appeal.ownerId)}</small></div></div><div class="ap-detail-grid"><div><small>Motivo</small><b>${esc(reasonNames[appeal.reason] || appeal.reason)}</b></div><div><small>Enviada em</small><b>${time(appeal.createdAt)}</b></div>${appeal.reason === "ban" ? `<div class="ap-full-detail"><small>E-mail informado para contato</small><b>${esc(appeal.email || "Não informado")}</b><small>Uso restrito às comunicações desta apelação.</small></div>` : ""}</div><div class="ap-description-block"><small>Descrição</small><p>${esc(appeal.description).replace(/\n/g,"<br>")}</p></div><div class="ap-description-block"><small>Evidências</small>${renderEvidence(appeal)}</div></section>
      <section class="ap-card ap-chat-card"><div class="ap-card-head"><div><h2>Conversa com o membro</h2><p>Mensagens visíveis ao membro e à equipe autorizada.</p></div><span class="ap-live-indicator">CHAT PRIVADO</span></div><div id="ap-chat-log" class="ap-chat-log">${renderMessages(appeal, true)}</div>${canChat ? `<form id="ap-chat-form" class="ap-chat-form"><textarea name="content" rows="3" maxlength="4000" placeholder="Escreva uma mensagem ao membro..."></textarea><div class="ap-chat-actions"><label class="ap-file-button">＋ Evidências<input type="file" id="ap-chat-files" multiple accept="image/png,image/jpeg,image/webp,image/gif" hidden/></label><span id="ap-chat-file-label" class="ap-muted"></span><button class="ap-primary" type="submit">Enviar mensagem ↗</button></div></form>` : ["accepted","rejected","closed"].includes(appeal.status) ? `<div class="ap-warning">Esta apelação está finalizada. A conversa está disponível para consulta.</div>` : `<div class="ap-warning">Apenas o atendente responsável ou um gerente pode conversar neste atendimento. Para começar, assuma a apelação.</div>`}</section>
      <section class="ap-card"><div class="ap-card-head"><div><h2>Registro interno da equipe</h2><p>Notas internas não aparecem para o membro.</p></div></div><div class="ap-internal-notes">${(appeal.internalNotes || []).map(note => `<div class="ap-note"><b>${esc(note.authorName)}</b><time>${time(note.at)}</time><p>${esc(note.note)}</p></div>`).join("") || `<p class="ap-muted">Nenhuma nota interna registrada.</p>`}</div>${canInternalNote ? `<form id="ap-internal-form" class="ap-chat-form"><textarea name="note" rows="2" maxlength="2000" placeholder="Adicionar uma nota interna..."></textarea><div class="ap-chat-actions"><button class="ap-secondary-button" type="submit">Salvar nota interna</button></div></form>` : `<p class="ap-privacy-note">Somente o responsável ou um gerente pode adicionar notas internas.</p>`}</section>
    </section><aside class="ap-side-column">
      <section class="ap-card ap-control-card"><div class="ap-card-head"><div><h2>Controle do atendimento</h2><p>Responsável, estado e decisões.</p></div></div><div class="ap-assignee-status">${assigned ? `<div class="ap-staff-profile" style="--profile-accent:${esc(assigned.color || "#ef1748")}">${avatar({ userId: assigned.userId, avatar: assigned.avatarUrl, displayName: assigned.displayName })}<div><b>${esc(assigned.displayName)}</b><small>${isOwner ? "Você é o responsável" : "Atendente responsável"}</small></div></div>` : `<p class="ap-warning">Esta apelação ainda não tem responsável.</p>`}</div>
        ${!appeal.assignedTo && perms.canAssume ? `<button class="ap-primary ap-wide" id="ap-assume">Assumir apelação</button>` : ""}
        ${canCall ? `<button class="ap-secondary-button ap-wide" id="ap-call">Chamar membro</button>` : ""}
        ${perms.canManage ? `<button class="ap-secondary-button ap-wide" id="ap-release">Liberar responsável</button><div class="ap-transfer"><label>Transferir para ID Discord</label><input id="ap-transfer-id" placeholder="ID do atendente"/><button class="ap-secondary-button ap-wide" id="ap-transfer">Transferir atendimento</button></div>` : ""}
        ${canChangeStatus ? `<div class="ap-status-actions"><label>Alterar estado</label><select id="ap-next-status">${(perms.canManage ? Object.entries(statuses).filter(([key]) => perms.canDecide || !["accepted","rejected"].includes(key)) : [["accepted","Aceita"],["rejected","Rejeitada"]]).map(([key,val])=>`<option value="${key}" ${appeal.status===key?"selected":""}>${val}</option>`).join("")}</select><textarea id="ap-justification" rows="3" placeholder="Justificativa obrigatória para aceitar ou rejeitar..."></textarea><button class="ap-primary ap-wide" id="ap-save-status">Salvar estado / decisão</button><small>Para aceitar ou rejeitar, informe uma justificativa de pelo menos 10 caracteres.</small></div>` : `<p class="ap-privacy-note">Apenas a pessoa responsável e os gerentes podem alterar o atendimento ou registrar uma decisão.</p>`}
      </section>
      <section class="ap-card"><div class="ap-card-head"><div><h2>Histórico de auditoria</h2><p>Registro interno das ações.</p></div></div><div class="ap-audit-list">${(appeal.audit || []).slice().reverse().map(entry => `<div><b>${esc(entry.actorName)}</b><span>${esc(entry.action.replaceAll("_"," "))}</span><time>${time(entry.at)}</time></div>`).join("") || `<p class="ap-muted">Sem eventos registrados.</p>`}</div></section>
    </aside></div>`;
  bindLogout();
  $("#ap-back-queue").addEventListener("click", () => { selectedAppealId = null; reloadStaffList(); });
  $("#ap-chat-form")?.addEventListener("submit", sendStaffMessage);
  $("#ap-chat-files")?.addEventListener("change", e => { $("#ap-chat-file-label").textContent = `${e.target.files.length} arquivo(s)`; });
  $("#ap-internal-form")?.addEventListener("submit", saveInternalNote);
  $("#ap-assume")?.addEventListener("click", () => staffAction("assume"));
  $("#ap-call")?.addEventListener("click", () => staffAction("call"));
  $("#ap-release")?.addEventListener("click", () => staffAction("release"));
  $("#ap-transfer")?.addEventListener("click", () => staffAction("transfer", { targetStaffId: $("#ap-transfer-id").value.trim() }));
  $("#ap-save-status")?.addEventListener("click", saveStatus);
  if (poller) clearInterval(poller); poller = setInterval(() => refreshChat("staff"), 12000);
}
async function sendStaffMessage(event) {
  event.preventDefault(); const form = event.currentTarget; const button = form.querySelector("button[type=submit]"); button.disabled = true;
  try {
    const attachments = await readFiles($("#ap-chat-files"), 4, 2 * 1024 * 1024);
    const sent = await api("/api/appeals", { method: "POST", body: JSON.stringify({ action: "message", appealId: selectedAppealId, content: form.elements.content.value, attachments }) });
    if (sent.delivery && !sent.delivery.delivered) showToast("Mensagem salva, mas a DM/e-mail não foi entregue. A falha foi registrada e a equipe foi alertada.", true);
    await openStaffAppeal(selectedAppealId);
  } catch (error) { showToast(error.message, true); button.disabled = false; }
}
async function staffAction(action, extra = {}) {
  const button = $("#ap-" + action); if (button) button.disabled = true;
  try {
    await api("/api/appeals", { method: "PATCH", body: JSON.stringify({ action, appealId: selectedAppealId, ...extra }) });
    showToast(action === "call" ? "Convite processado." : "Atendimento atualizado.");
    await reloadStaffList(); await openStaffAppeal(selectedAppealId);
  } catch (error) { showToast(error.message, true); if (button) button.disabled = false; }
}
async function saveStatus() {
  const status = $("#ap-next-status").value; const justification = $("#ap-justification").value;
  if (!status) return showToast("Selecione um estado válido.", true);
  if (["accepted","rejected"].includes(status) && justification.trim().length < 10) return showToast("Informe uma justificativa de pelo menos 10 caracteres.", true);
  try {
    const result = await api("/api/appeals", { method: "PATCH", body: JSON.stringify({ action: "status", appealId: selectedAppealId, status, justification }) });
    showToast(result.delivery && !result.delivery.delivered ? "Decisão registrada, mas a notificação do membro falhou. A equipe foi alertada." : "Estado atualizado.", Boolean(result.delivery && !result.delivery.delivered)); await reloadStaffList(); await openStaffAppeal(selectedAppealId);
  } catch (error) { showToast(error.message, true); }
}
async function saveInternalNote(event) {
  event.preventDefault(); const form = event.currentTarget;
  try { await api("/api/appeals", { method: "PATCH", body: JSON.stringify({ action: "internal-note", appealId: selectedAppealId, note: form.elements.note.value }) }); await openStaffAppeal(selectedAppealId); showToast("Nota interna salva."); }
  catch (error) { showToast(error.message, true); }
}
async function saveProfile(event) {
  event.preventDefault(); const form = event.currentTarget;
  const patch = { action: "profile", displayName: form.elements.displayName.value, description: form.elements.description.value, avatarUrl: form.elements.avatarUrl.value, color: form.elements.color.value };
  try { const data = await api("/api/appeals", { method: "PATCH", body: JSON.stringify(patch) }); profile = data.profile; showToast("Perfil atualizado."); }
  catch (error) { showToast(error.message, true); }
}
async function boot() {
  try {
    const auth = await api("/api/auth/user"); me = auth.user;
    eligibility = auth.eligibility;
    if (mode === "staff") {
      if (!eligibility.isStaff) { root.innerHTML = `${header("Acesso restrito", "Esta área é exclusiva dos cargos autorizados da alta staff.")}<section class="ap-card ap-access-denied"><h2>Você não tem acesso a esta Central.</h2><p>Entre em contato com a administração para confirmar suas permissões.</p><a class="ap-primary" href="/appeals.html">Acessar minhas apelações</a></section>`; bindLogout(); return; }
      await loadStaff();
    } else {
      if (!eligibility.canSubmit && !eligibility.isStaff) { /* ainda é possível consultar apelações anteriores, mesmo que a elegibilidade tenha mudado */ }
      await loadMember();
    }
  } catch (error) {
    if (error.message.includes("Entre com sua conta Discord")) loginScreen(mode === "staff");
    else root.innerHTML = `<section class="ap-card ap-access-denied"><h1>Não foi possível abrir a Central</h1><p>${esc(error.message)}</p><a class="ap-primary" href="/">Voltar ao início</a></section>`;
  }
}
boot();
