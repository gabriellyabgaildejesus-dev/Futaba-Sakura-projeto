const MODULES = [
  { key: "antiSpam", name: "Anti-Spam", desc: "Detecta repetição de conteúdo, emojis e anexos.", icon: "▤", tip: "Ajuste os limites com cuidado para não confundir conversas rápidas com spam." },
  { key: "antiFlood", name: "Anti-Flood", desc: "Controla a quantidade de mensagens por membro e janela de tempo.", icon: "◷", tip: "Comece com uma janela de detecção conservadora e observe o ritmo normal do servidor." },
  { key: "mentionSpam", name: "Spam de Menções", desc: "Identifica excesso de menções a pessoas e cargos.", icon: "＠", tip: "Defina um limite que proteja a comunidade sem atrapalhar avisos legítimos." },
  { key: "autoMod", name: "AutoMod", desc: "Bloqueia palavras e expressões definidas pela administração.", icon: "⌕", tip: "Use termos específicos e revise a lista para evitar bloqueios acidentais." },
  { key: "antiBot", name: "Anti-Bot", desc: "Coloca bots não confiáveis em quarentena e exige autenticação.", icon: "♟", tip: "Cadastre integrações confiáveis e configure a senha no painel do Discord antes de ativar." },
  { key: "antiRaid", name: "Anti-Raid", desc: "Reage a sequências incomuns de entradas no servidor.", icon: "⚡", tip: "O bloqueio temporário deve ser proporcional ao tamanho e ao movimento do servidor." },
  { key: "antiNuke", name: "Anti-Nuke", desc: "Monitora ações administrativas destrutivas em sequência.", icon: "◈", tip: "Teste os limites com cuidado; ações de proteção podem afetar administradores." },
  { key: "antiLink", name: "Anti-Link", desc: "Controla links, blacklist, whitelist e cargos autorizados.", icon: "↗", tip: "A blacklist tem prioridade sobre a whitelist e sobre cargos autorizados." }
];
const COMMANDS = [
  ["ban", "@membro [motivo]", "Bane um membro do servidor.", "Requer permissão de banir e respeito à hierarquia do Discord."],
  ["unban", "ID [motivo]", "Remove o banimento de um usuário pelo ID.", "O ID da conta precisa ser informado."],
  ["kick", "@membro [motivo]", "Expulsa um membro do servidor.", "Requer permissão de expulsar e respeito à hierarquia."],
  ["mute", "@membro [10m] [motivo]", "Aplica timeout por duração configurável.", "Aceita s, m, h e d; sem duração, usa 10 minutos."],
  ["unmute", "@membro", "Remove o timeout ativo de um membro.", "O bot precisa da permissão Moderar membros."],
  ["warn", "@membro [motivo]", "Registra uma advertência no histórico persistente.", "A advertência também é enviada ao canal de punições."],
  ["unwarn", "@membro", "Remove a advertência ativa mais recente.", "Atualiza o estado do registro correspondente."],
  ["punições", "@membro [página]", "Consulta o histórico persistente de punições do membro.", "O histórico também contempla registros de membros que saíram do servidor."],
  ["lock", "", "Bloqueia o canal atual para mensagens comuns.", "Guarda as permissões anteriores para permitir a restauração."],
  ["unlock", "", "Restaura as permissões anteriores do canal atual.", "Usa o snapshot salvo pelo comando !lock."],
  ["clear", "50 [@membro]", "Remove mensagens recentes do canal, opcionalmente filtrando por membro.", "Aceita até 1.000 mensagens por execução; !clear @membro usa a quantidade padrão configurada."]
];
const LABELS = {
  enabled: "Ativar módulo", watchChannelIds: "Canais monitorados", publicChannelId: "Canal de avisos públicos", logChannelId: "Canal de registros", staffChannelId: "Canal de alertas da equipe", staffRoleIds: "Cargos mencionados nos alertas",
  publicMessage: "Mensagem pública", dmMessage: "Mensagem enviada por DM", bannerUrl: "Banner dos avisos (HTTPS)",
  repeats: "Repetições para detectar", repeatWindowSeconds: "Janela de repetição (segundos)", emojiLimit: "Limite de emojis", messageLimit: "Limite de mensagens", windowSeconds: "Janela de detecção (segundos)", mentionLimit: "Limite de menções", joinLimit: "Entradas para acionar", lockdownMinutes: "Duração do bloqueio (minutos)", actionLimit: "Ações administrativas para acionar",
  deleteMessage: "Excluir mensagens detectadas", deleteTriggerMessage: "Excluir a mensagem que acionou a regra", muteDurationSeconds: "Timeout automático (segundos; 0 desativa)", deleteDelaySeconds: "Atraso para excluir mensagens (segundos; 0 mantém)", noticeDeleteDelaySeconds: "Atraso para excluir o aviso público (segundos; 0 mantém)", autoBanAdmin: "Tentar banir executor em nuke confirmado",
  words: "Termos proibidos", blacklist: "Blacklist de links/domínios", whitelist: "Whitelist de links/domínios", gifExtensions: "Extensões GIF permitidas", gifWhitelistEnabled: "Permitir GIFs reconhecidos", authorizedRoleIds: "Cargos autorizados a enviar links", trustedBotIds: "IDs dos bots confiáveis", monitoredAuditActions: "Tipos de evento auditados",
  quarantineRoleId: "Cargo de quarentena", authTimeoutMs: "Prazo de autenticação (milissegundos)", quarantineMs: "Duração máxima da quarentena (milissegundos)",
  authEmbedTitle: "Título do pedido de autenticação", authEmbedDescription: "Descrição do pedido de autenticação", authEmbedColor: "Cor do pedido (#RRGGBB)", authEmbedFooter: "Rodapé do pedido", authSuccessTitle: "Título de autenticação concluída", authSuccessDescription: "Mensagem após autenticação", authSuccessColor: "Cor após autenticação (#RRGGBB)", authReleasedTitle: "Título ao liberar bot confiável", authReleasedDescription: "Mensagem ao liberar bot confiável", authReleasedColor: "Cor ao liberar bot confiável (#RRGGBB)", authExpiredTitle: "Título quando o prazo expira", authExpiredDescription: "Mensagem após expiração", authExpiredColor: "Cor após expiração (#RRGGBB)", authExpiredFailureDescription: "Mensagem se o banimento falhar", passwordSuccessMessage: "Resposta privada após autenticação", passwordIncorrectMessage: "Resposta privada para senha incorreta", passwordExpiredMessage: "Resposta privada de prazo expirado", passwordUnavailableMessage: "Resposta privada para autenticação indisponível", passwordNotConfiguredMessage: "Resposta privada quando a senha não está configurada", passwordBotMissingMessage: "Resposta privada quando o bot não está no servidor",
  logEmbedAuthor: "Autor do embed de registros", logEmbedAuthorIconUrl: "Ícone do autor (HTTPS)", logEmbedFooterIconUrl: "Ícone do rodapé (HTTPS)", logEmbedTimestamp: "Mostrar data e horário no registro", logEmbedIncludeDefaultFields: "Incluir campos padrão no registro", logEmbedFields: "Campos adicionais do registro (nome|valor|inline)", logEmbedTitle: "Título do embed de registros", logEmbedDescription: "Descrição do embed de registros", logEmbedColor: "Cor do embed de registros (#RRGGBB)", logEmbedFooter: "Rodapé do embed de registros", logEmbedImageUrl: "Imagem do embed de registros (HTTPS)", logEmbedThumbnailUrl: "Miniatura do embed de registros (HTTPS)",
  staffEmbedAuthor: "Autor do embed de alerta", staffEmbedAuthorIconUrl: "Ícone do autor do alerta (HTTPS)", staffEmbedFooterIconUrl: "Ícone do rodapé do alerta (HTTPS)", staffEmbedTimestamp: "Mostrar data e horário no alerta", staffEmbedIncludeDefaultFields: "Incluir campos padrão no alerta", staffEmbedFields: "Campos adicionais do alerta (nome|valor|inline)", staffEmbedTitle: "Título do embed de alerta", staffEmbedDescription: "Descrição do embed de alerta", staffEmbedColor: "Cor do embed de alerta (#RRGGBB)", staffEmbedFooter: "Rodapé do embed de alerta", staffEmbedImageUrl: "Imagem do embed de alerta (HTTPS)", staffEmbedThumbnailUrl: "Miniatura do embed de alerta (HTTPS)",
  prefix: "Prefixo dos comandos", defaultClearCount: "Quantidade padrão do comando clear"
};
const HINTS = {
  watchChannelIds: "Um ID de canal por linha. Somente esses canais serão monitorados pelo módulo.",
  publicChannelId: "Informe o ID do canal onde a Futaba publicará o aviso público.",
  logChannelId: "Informe o ID do canal privado destinado aos registros de moderação.",
  staffChannelId: "Informe o ID do canal onde a equipe recebe alertas de infrações.",
  staffRoleIds: "Um ID de cargo por linha. Esses cargos serão mencionados nos alertas da equipe.",
  authorizedRoleIds: "Esses cargos podem enviar links fora da whitelist; a blacklist continua tendo prioridade.",
  trustedBotIds: "Um ID de bot por linha. Bots confiáveis são ignorados apenas pelo Anti-Bot; os outros módulos continuam ativos.",
  words: "Um termo ou frase por linha. A comparação ignora diferenças de maiúsculas e acentos.",
  whitelist: "Um domínio ou caminho por linha. A whitelist libera links para qualquer membro.",
  blacklist: "Um domínio ou caminho por linha. A blacklist sempre prevalece sobre a whitelist e sobre cargos autorizados.",
  gifExtensions: "Exemplo: .gif e .gifv. Use apenas extensões reconhecidas.",
  monitoredAuditActions: "Um tipo de evento por linha, usando os nomes listados no projeto do bot.",
  passwordSuccessMessage: "Resposta enviada somente à pessoa que concluiu a autenticação.",
  authEmbedDescription: "Os campos automáticos de identificação do bot, prazo e estado continuam presentes.",
  publicMessage: "Variáveis: {user}, {channel}, {type}, {action}, {content}.",
  dmMessage: "Variáveis: {user}, {channel}, {type}, {action}, {content}.",
  deleteDelaySeconds: "0 mantém as mensagens; valores positivos agendam a limpeza das mensagens do membro dentro da janela detectada.",
  noticeDeleteDelaySeconds: "Temporizador independente da exclusão das mensagens do membro.",
  muteDurationSeconds: "Use 0 para desativar timeout automático.",
  authTimeoutMs: "O padrão atual é 300000 ms (5 minutos).",
  quarantineMs: "O valor é salvo em milissegundos. O padrão atual é 604800000 ms (7 dias).",
  logEmbedTitle: "Variáveis: {type}, {module}, {server}.",
  logEmbedDescription: "Variáveis disponíveis: {user}, {userId}, {channel}, {content}, {infraction}, {action}, {type}, {module}, {server}.",
  staffEmbedTitle: "Variáveis: {type}, {module}, {server}.",
  staffEmbedDescription: "Variáveis disponíveis: {user}, {userId}, {channel}, {content}, {infraction}, {action}, {type}, {module}, {server}.",
  logEmbedFields: "Um campo por linha: nome|valor|true. Variáveis: {user}, {userId}, {channel}, {content}, {infraction}, {action}, {type}, {module}, {server}.",
  staffEmbedFields: "Um campo por linha: nome|valor|true. Variáveis: {user}, {userId}, {channel}, {content}, {infraction}, {action}, {type}, {module}, {server}.",
  bannerUrl: "Use uma imagem HTTPS pública. Deixe vazio para não exibir banner."
};
const $ = selector => document.querySelector(selector);
let state = { config: null, resources: null, user: null, page: "home", busy: false };
const PAGE_META = {
  home: ["Visão Geral", "Painel administrativo da Futaba Sakura."],
  commands: ["Comandos de moderação", "Consulte os comandos manuais disponíveis e seus formatos de uso."],
  punishments: ["Registro de punições", "Personalize o canal e a aparência dos registros publicados pela Futaba."],
  general: ["Configurações gerais", "Ajuste o prefixo e os padrões dos comandos de moderação."],
  about: ["Sobre a Futaba", "Conheça os recursos do painel e as proteções disponíveis."],
  appealsSettings: ["Central de Apelações", "Configure permissões, alertas e regras de atendimento."]
};

function escapeHtml(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c])); }
function escapeAttr(value) { return escapeHtml(value); }
function toast(message, isError = false) {
  const el = $("#toast"); if (!el) return;
  el.textContent = message; el.classList.remove("hidden", "error"); if (isError) el.classList.add("error");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.add("hidden"), 4300);
}
async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { ...(options.body ? { "content-type": "application/json" } : {}), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Falha de comunicação (${response.status}).`);
  return data;
}
function displayName() { return state.user?.globalName || state.user?.username || "Administradora"; }
function switchToDashboard() { $("#welcome").classList.add("hidden"); $("#dashboard").classList.remove("hidden"); }
function setPage(page) {
  state.page = page;
  document.querySelectorAll(".nav-item[data-page]").forEach(button => button.classList.toggle("active", button.dataset.page === page));
  const module = MODULES.find(item => item.key === page);
  const meta = PAGE_META[page] || (module ? [module.name, module.desc] : ["Futaba Sakura", "Painel administrativo do POOL PARTY."]);
  $("#breadcrumb-current").textContent = meta[0];
  $("#page-title").textContent = meta[0];
  $("#page-subtitle").textContent = meta[1];
  $("#dashboard").classList.toggle("is-home-page", page === "home");
  $("#dashboard").classList.remove("nav-open");
  $("#mobile-nav-toggle").setAttribute("aria-expanded", "false");
  render();
}
function render() {
  if (!state.config) return;
  if (state.page === "home") renderHome();
  else if (state.page === "commands") renderCommands();
  else if (state.page === "punishments") renderPunishments();
  else if (state.page === "general") renderGeneral();
  else if (state.page === "about") renderAbout();
  else if (state.page === "appealsSettings") renderAppealsSettings();
  else renderModule(state.page);
}
function moduleStatus(module) {
  const active = Boolean(state.config[module.key]?.enabled);
  return `<span class="status-pill ${active ? "on" : ""}">${active ? "Ativo" : "Desativado"}</span>`;
}
function renderHome() {
  const enabled = MODULES.filter(module => state.config[module.key]?.enabled).length;
  const trusted = state.config.antiBot?.trustedBotIds?.length || 0;
  const punishmentChannel = state.config.general?.logChannelId;
  const stats = [
    ["Módulos ativos", `${enabled}/8`, "Proteções habilitadas", "◈", "#ff2457"],
    ["Comandos manuais", String(COMMANDS.length), "Ferramentas disponíveis", "⚖", "#f35b83"],
    ["Bots confiáveis", String(trusted), "Exceções cadastradas no Anti-Bot", "♟", "#ffffff"],
    ["Canal de punições", punishmentChannel ? "Configurado" : "Pendente", punishmentChannel ? "Destino dos registros definido" : "Defina o canal de registros", "▤", punishmentChannel ? "#25d69a" : "#ffbd55"]
  ];
  const statusRows = MODULES.map(module => `<div class="module-status-row"><span class="module-symbol">${module.icon}</span><div><strong>${module.name}</strong><small>${escapeHtml(module.desc)}</small></div>${moduleStatus(module)}<button class="text-link" data-open="${module.key}">Configurar</button></div>`).join("");
  const quickActions = [
    ["commands", "⚖", "Comandos de moderação", "Consultar os 11 comandos"],
    ["punishments", "▤", "Registro de punições", "Canal e aparência dos registros"],
    ["general", "⚙", "Configurações gerais", "Prefixo e padrões de moderação"],
    ["antiSpam", "▤", "Configurar Anti-Spam", "Limites, filtros e notificações"]
  ];
  $("#content").innerHTML = `
    <section class="home-hero card">
      <div class="hero-copy"><div class="eyebrow"><span></span> POOL PARTY <b> / </b> PAINEL ADMINISTRATIVO</div><h2>Visão <span>Geral</span></h2><p>Gerencie as proteções, acompanhe as configurações e mantenha as ferramentas de moderação organizadas em um só lugar.</p></div>
      <div class="home-hero-art" role="img" aria-label="Arte da Futaba Sakura com identidade visual preta e vermelha"></div>
      <span class="home-hero-tag">FUTABA SAKURA <i></i></span>
    </section>
    <section class="stat-grid">${stats.map(([label,value,note,icon,color]) => `<article class="stat-card card" style="--accent:${color}"><div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div><strong class="stat-value">${escapeHtml(value)}</strong><div class="stat-note">${escapeHtml(note)}</div></article>`).join("")}</section>
    <section class="home-grid home-dashboard-grid">
      <section class="card home-status-card"><div class="card-head"><div><h2><span class="head-icon">◈</span> Status dos módulos</h2><p>Estado atual das oito proteções do servidor.</p></div><span class="status-pill on">${enabled}/8 ativos</span></div><div class="module-status-list">${statusRows}</div></section>
      <section class="card home-actions-card"><div class="card-head"><div><h2><span class="head-icon">⚡</span> Ações rápidas</h2><p>Acesse as áreas administrativas mais utilizadas.</p></div></div><div class="quick-grid">${quickActions.map(([page,icon,title,desc]) => `<button class="quick-action" data-open="${page}"><span class="qa-icon">${icon}</span><span><strong>${title}</strong><small>${desc}</small></span><b>↗</b></button>`).join("")}</div><div class="home-system-note"><span class="system-note-icon">✓</span><div><strong>Integração do painel</strong><p>As configurações são carregadas pela API privada da Futaba e validadas antes de serem salvas.</p></div></div></section>
    </section>
    <section class="home-bottom-grid">
      <article class="card system-summary"><div class="card-head"><div><h2><span class="head-icon">▥</span> Resumo do sistema</h2><p>Informações de configuração do servidor.</p></div></div><div class="summary-list"><div><span>Bot</span><strong class="summary-good"><i></i> Online</strong></div><div><span>Proteções habilitadas</span><strong>${enabled} de 8</strong></div><div><span>Comandos manuais</span><strong>${COMMANDS.length} disponíveis</strong></div><div><span>Canal de punições</span><strong class="${punishmentChannel ? "summary-good" : "summary-pending"}">${punishmentChannel ? "Configurado" : "Pendente"}</strong></div></div></article>
      <article class="card home-tip"><div class="tip-topline"><span class="head-icon">✦</span><h2>Recomendação</h2></div><p>Defina o canal de registros de punição e revise os canais de alertas antes de habilitar ações automáticas.</p><button class="text-link" data-open="punishments">Abrir registro de punições →</button></article>
    </section>`;
  bindOpenButtons();
}

function groupForField(key, value, moduleKey) {
  if (["watchChannelIds", "publicChannelId", "logChannelId", "staffChannelId", "staffRoleIds", "authorizedRoleIds", "quarantineRoleId"].includes(key)) return "Canais e cargos";
  if (["words", "whitelist", "blacklist", "gifExtensions", "trustedBotIds", "monitoredAuditActions"].includes(key)) return "Regras, listas e exceções";
  if (key.startsWith("auth") || key.startsWith("password")) return "Autenticação e mensagens de estado";
  if (key.startsWith("logEmbed")) return "Aparência dos registros";
  if (key.startsWith("staffEmbed")) return "Aparência dos alertas";
  if (["publicMessage", "dmMessage", "bannerUrl"].includes(key)) return "Mensagens e avisos";
  if (/(Limit|Window|Seconds|Duration|Timeout|Minutes|Repeats|emojiLimit)/i.test(key)) return "Detecção e limites";
  if (typeof value === "boolean" || ["deleteMessage", "deleteTriggerMessage", "autoBanAdmin"].includes(key)) return "Ações automáticas";
  return "Comportamento do módulo";
}
function fieldHelp(key) {
  if (HINTS[key]) return HINTS[key];
  if (/ChannelId$/.test(key)) return "Informe o ID do canal do Discord. A API valida o formato antes de salvar.";
  if (/RoleId$/.test(key) || /RoleIds$/.test(key)) return "Informe IDs de cargos do Discord. Para listas, use um ID por linha.";
  if (/Url$/i.test(key)) return "Use um endereço HTTPS público e acessível pelo Discord.";
  if (key.endsWith("Color")) return "Informe uma cor hexadecimal no formato #RRGGBB.";
  if (Array.isArray(valueForCurrentField(key))) return "Um item por linha.";
  return "";
}
function valueForCurrentField(key) { return state.config?.[state.page]?.[key]; }
function renderDiscordSelect(key, value, multiple = false) {
  const isRole = /RoleId/.test(key) || ["staffRoleIds", "authorizedRoleIds"].includes(key);
  const source = isRole ? (state.resources?.roles || []) : (state.resources?.channels || []);
  if (!source.length) return "";
  const selected = new Set((multiple ? (Array.isArray(value) ? value : []) : (value ? [value] : [])));
  const known = new Set(source.map(item => item.id));
  const options = source.map(item => {
    const label = isRole ? `@${item.name}${item.managed ? " • integração" : ""}` : `${item.parentName ? `${item.parentName} / ` : "#"}${item.name}`;
    return `<option value="${escapeAttr(item.id)}" ${selected.has(item.id) ? "selected" : ""}>${escapeHtml(label)}</option>`;
  });
  const savedIds = [...selected].filter(id => !known.has(id));
  for (const id of savedIds) options.unshift(`<option value="${escapeAttr(id)}" selected>ID salvo: ${escapeHtml(id)}</option>`);
  const type = multiple ? "multiple size=5" : "";
  return `<select name="${escapeAttr(key)}" ${type} ${multiple ? 'data-multiple-select="true"' : ""}><option value="" ${!selected.size ? "selected" : ""}>${multiple ? "Selecione os itens abaixo" : isRole ? "Selecione um cargo" : "Selecione um canal"}</option>${options.join("")}</select>`;
}
function renderField(key, value) {
  const label = LABELS[key] || key.replace(/([A-Z])/g, " $1").replace(/^./, char => char.toUpperCase());
  const idList = ["watchChannelIds", "staffRoleIds", "authorizedRoleIds", "trustedBotIds"].includes(key);
  const hint = fieldHelp(key);
  const singleDiscordId = ["publicChannelId", "logChannelId", "staffChannelId", "quarantineRoleId"].includes(key);
  const multiDiscordIds = ["watchChannelIds", "staffRoleIds", "authorizedRoleIds"].includes(key);
  if (singleDiscordId && state.resources) {
    const select = renderDiscordSelect(key, value, false);
    if (select) return `<div class="field"><label>${escapeHtml(label)}</label>${select}${hint ? `<small>${escapeHtml(hint)}</small>` : ""}</div>`;
  }
  if (multiDiscordIds && state.resources) {
    const select = renderDiscordSelect(key, value, true);
    if (select) return `<div class="field full"><label>${escapeHtml(label)}</label>${select}<small>Use Ctrl/Cmd para selecionar mais de um item. ${escapeHtml(hint || "")}</small></div>`;
  }
  if (typeof value === "boolean") return `<div class="field"><label>${escapeHtml(label)}</label><label class="check-field"><input type="checkbox" name="${escapeAttr(key)}" ${value ? "checked" : ""}/> ${escapeHtml(label)}</label>${hint ? `<small>${escapeHtml(hint)}</small>` : ""}</div>`;
  if (Array.isArray(value)) return `<div class="field ${["words", "whitelist", "blacklist", "monitoredAuditActions", "logEmbedFields", "staffEmbedFields"].includes(key) ? "full" : ""}"><label for="field-${escapeAttr(key)}">${escapeHtml(label)}</label><textarea id="field-${escapeAttr(key)}" name="${escapeAttr(key)}" spellcheck="false" placeholder="${idList ? "Um ID por linha" : "Um item por linha"}">${escapeHtml(value.join("\n"))}</textarea>${hint ? `<small>${escapeHtml(hint)}</small>` : ""}</div>`;
  if (typeof value === "number") return `<div class="field"><label for="field-${escapeAttr(key)}">${escapeHtml(label)}</label><input id="field-${escapeAttr(key)}" name="${escapeAttr(key)}" type="number" min="0" step="1" value="${value}"/>${hint ? `<small>${escapeHtml(hint)}</small>` : ""}</div>`;
  if (typeof value === "string" || value === null) {
    const current = value ?? "";
    const multiline = /(Message|Description|publicMessage|dmMessage)/i.test(key) || current.length > 100;
    const type = /Url$/i.test(key) ? "url" : "text";
    const full = multiline || ["publicMessage", "dmMessage", "bannerUrl"].includes(key);
    return `<div class="field ${full ? "full" : ""}"><label for="field-${escapeAttr(key)}">${escapeHtml(label)}</label>${multiline ? `<textarea id="field-${escapeAttr(key)}" name="${escapeAttr(key)}">${escapeHtml(current)}</textarea>` : `<input id="field-${escapeAttr(key)}" name="${escapeAttr(key)}" type="${type}" value="${escapeAttr(current)}" placeholder="${key.endsWith("Id") ? "ID do Discord" : ""}"/>`}${hint ? `<small>${escapeHtml(hint)}</small>` : ""}</div>`;
  }
  return "";
}
function groupFields(data, moduleKey) {
  const groups = new Map();
  for (const [key, value] of Object.entries(data)) {
    if (key === "enabled" || key === "passwordConfigured" || key === "verificationLevelBeforeLockdown" || key === "lockdownUntil") continue;
    const group = groupForField(key, value, moduleKey);
    if (!groups.has(group)) groups.set(group, []);
    groups.get(group).push([key, value]);
  }
  const order = ["Comportamento do módulo", "Canais e cargos", "Detecção e limites", "Ações automáticas", "Regras, listas e exceções", "Mensagens e avisos", "Autenticação e mensagens de estado", "Aparência dos registros", "Aparência dos alertas"];
  return order.filter(name => groups.has(name)).map(name => ({ name, fields: groups.get(name) }));
}
function sectionIcon(name) {
  return ({ "Comportamento do módulo": "⚙", "Canais e cargos": "♙", "Detecção e limites": "◷", "Ações automáticas": "⚡", "Regras, listas e exceções": "⌕", "Mensagens e avisos": "▤", "Autenticação e mensagens de estado": "♟", "Aparência dos registros": "▧", "Aparência dos alertas": "✦" })[name] || "✦";
}
function modulePreview(data, key) {
  const title = data.staffEmbedTitle || data.logEmbedTitle || data.authEmbedTitle || "Aviso da Futaba";
  const description = data.staffEmbedDescription || data.logEmbedDescription || data.authEmbedDescription || data.publicMessage || "A ação configurada foi executada no servidor.";
  const color = data.staffEmbedColor || data.logEmbedColor || data.authEmbedColor || "#ef72c5";
  const footer = data.staffEmbedFooter || data.logEmbedFooter || data.authEmbedFooter || "Futaba Sakura • POOL PARTY";
  const img = data.staffEmbedImageUrl || data.logEmbedImageUrl || data.bannerUrl || "";
  const channel = data.staffChannelId || data.logChannelId || data.publicChannelId;
  const cleanTitle = title.replaceAll("{type}", "Spam detectado").replaceAll("{module}", MODULES.find(m => m.key === key)?.name || "Futaba").replaceAll("{server}", "POOL PARTY");
  const cleanDesc = description.replaceAll("{user}", "@Membro").replaceAll("{userId}", "123456789012345678").replaceAll("{channel}", "geral").replaceAll("{content}", "mensagem de exemplo").replaceAll("{type}", "Spam detectado").replaceAll("{module}", MODULES.find(m => m.key === key)?.name || "Futaba").replaceAll("{server}", "POOL PARTY");
  return `<div class="card preview-card"><div class="card-head"><div><h3><span class="head-icon">◉</span> Prévia do resultado</h3><p>Exemplo ilustrativo; os valores reais vêm das configurações.</p></div></div><div class="preview-window"><div class="discord-message-head"><span class="bot-avatar"></span><strong>Futaba Sakura</strong><span class="bot-tag">BOT</span><small>Hoje às 21:42</small></div><div class="discord-embed" style="--embed-color:${escapeAttr(/^#[0-9a-f]{6}$/i.test(color) ? color : "#ef72c5")}"><h4>${escapeHtml(cleanTitle)}</h4><p>${escapeHtml(cleanDesc)}</p>${img ? `<img class="preview-art" src="${escapeAttr(img)}" alt="Prévia de mídia" onerror="this.hidden=true"/>` : ""}<div class="preview-fields"><div><strong>Membro</strong>@Membro</div><div><strong>Ação</strong>Mensagem removida</div></div><div class="preview-footer">${escapeHtml(footer)}${channel ? " • Canal configurado" : " • Canal não definido"}</div></div></div></div>`;
}
function renderModule(key) {
  const module = MODULES.find(item => item.key === key);
  const data = state.config[key];
  if (!module || !data) { $("#content").innerHTML = `<div class="empty-note">As configurações deste módulo não estão disponíveis no momento.</div>`; return; }
  const groups = groupFields(data, key);
  const moduleIndex = MODULES.findIndex(item => item.key === key);
  const bannerAsset = moduleIndex % 2 === 0 ? "module-banner-red.jpg" : "module-banner-computer.jpg";
  const tabs = groups.map((group,index) => `<button type="button" class="module-tab ${index === 0 ? "active" : ""}" data-section-tab="${index}" aria-selected="${index === 0 ? "true" : "false"}"><span>${sectionIcon(group.name)}</span>${escapeHtml(group.name)}</button>`).join("");
  const sections = groups.map((group,index) => `<section class="card editor-section ${index === 0 ? "active" : ""}" data-editor-section="${index}" ${index === 0 ? "" : "hidden"}><div class="card-head"><div><h3><span class="head-icon">${sectionIcon(group.name)}</span>${escapeHtml(group.name)}</h3><p>Opções relacionadas a ${escapeHtml(group.name.toLowerCase())} do módulo ${escapeHtml(module.name)}.</p></div><span class="section-count">${group.fields.length} ${group.fields.length === 1 ? "opção" : "opções"}</span></div><div class="field-grid">${group.fields.map(([field,value]) => renderField(field,value)).join("")}</div></section>`).join("");
  const passwordNote = key === "antiBot" ? `<div class="password-notice">${data.passwordConfigured ? "✓ A senha do Anti-Bot já está configurada." : "⚠ A senha do Anti-Bot ainda não foi configurada."} A configuração e a troca da senha continuam sendo feitas pelo painel <code>/futaba painel</code> no Discord, por segurança.</div>` : "";
  $("#content").innerHTML = `<form id="module-form" data-module="${key}">
    <section class="module-hero" style="--module-banner:url('/assets/${bannerAsset}')"><div class="module-hero-copy"><span class="module-kicker">POOL PARTY <b> / </b> MÓDULO DE PROTEÇÃO</span><h2>${escapeHtml(module.name)}</h2><p>${escapeHtml(module.desc)}</p></div><div class="module-hero-state"><span class="module-state-dot"></span>${data.enabled ? "Módulo ativo" : "Módulo desativado"}</div></section>
    <div class="module-toolbar"><div class="module-toolbar-main"><span class="module-big-icon">${module.icon}</span><div><h2>Controle do módulo</h2><p>Ative ou desative esta proteção; as alterações detalhadas são aplicadas ao salvar.</p></div></div><label class="toggle-control"><input type="checkbox" name="enabled" ${data.enabled ? "checked" : ""}/><span class="toggle-track"></span><span class="toggle-state">${data.enabled ? "Módulo ativo" : "Módulo desativado"}</span></label></div>
    ${passwordNote}
    <div class="module-tabs" role="tablist" aria-label="Categorias de configuração">${tabs}</div>
    <div class="module-layout"><div class="editor-main">${sections}<section class="card save-card"><div class="form-actions"><small>As alterações só serão aplicadas depois de salvar.</small><button class="button-primary" type="submit">▣ Salvar configurações</button></div></section></div><aside class="editor-aside">${modulePreview(data,key)}<div class="tip-card"><span class="tip-icon">✦</span><h3>Orientação</h3><p>${escapeHtml(module.tip)}</p></div></aside></div>
  </form>`;
  const form = $("#module-form");
  form.addEventListener("submit", event => saveModule(event,key,data));
  form.addEventListener("change", event => { if (event.target.name === "enabled") form.querySelector(".toggle-state").textContent = event.target.checked ? "Módulo ativo" : "Módulo desativado"; });
  form.addEventListener("input", () => updateModulePreview(data,key));
  form.querySelectorAll("[data-section-tab]").forEach(tab => tab.addEventListener("click", () => {
    const selected = tab.dataset.sectionTab;
    form.querySelectorAll("[data-section-tab]").forEach(item => { const active = item.dataset.sectionTab === selected; item.classList.toggle("active",active); item.setAttribute("aria-selected",String(active)); });
    form.querySelectorAll("[data-editor-section]").forEach(section => { const active = section.dataset.editorSection === selected; section.hidden = !active; section.classList.toggle("active",active); });
  }));
}

function updateModulePreview(data,key) {
  const form = $("#module-form"); if (!form) return;
  const current = { ...data };
  for (const [name,value] of Object.entries(data)) {
    const el = form.elements.namedItem(name); if (!el) continue;
    if (typeof value === "boolean") current[name] = el.checked;
    else if (Array.isArray(value)) current[name] = el.tagName === "SELECT" ? Array.from(el.selectedOptions).map(option => option.value).filter(Boolean) : el.value.split(/\r?\n/).map(item => item.trim()).filter(Boolean);
    else current[name] = el.value;
  }
  const holder = form.querySelector(".editor-aside");
  if (holder) holder.innerHTML = `${modulePreview(current,key)}<div class="tip-card"><span class="tip-icon">♡</span><h3>Orientação</h3><p>${MODULES.find(m=>m.key===key)?.tip || "Revise as opções antes de salvar."}</p></div>`;
}
async function saveModule(event,key,original) {
  event.preventDefault();
  const form = event.currentTarget; const patch = {};
  for (const [name,value] of Object.entries(original)) {
    const element = form.elements.namedItem(name); if (!element) continue;
    if (typeof value === "boolean") patch[name] = element.checked;
    else if (Array.isArray(value)) patch[name] = element.tagName === "SELECT" ? Array.from(element.selectedOptions).map(option => option.value).filter(Boolean) : element.value.split(/\r?\n/).map(item => item.trim()).filter(Boolean);
    else if (typeof value === "number") patch[name] = Number(element.value);
    else if (typeof value === "string" || value === null) patch[name] = element.value.trim() === "" && value === null ? null : element.value;
  }
  await savePatch(key,patch,form.querySelector("button[type=submit]"));
}
function renderCommands() {
  const prefix = state.config.general?.prefix || "!";
  $("#content").innerHTML = `<div class="two-column"><section class="card"><div class="card-head"><div><h2><span class="head-icon">⚖</span> Comandos disponíveis</h2><p>Os comandos abaixo são enviados no chat do Discord; o site serve como referência e configuração.</p></div><span class="status-pill on">${COMMANDS.length} comandos</span></div><div class="command-grid">${COMMANDS.map(([name,args,description,detail]) => `<article class="command-card"><code>${escapeHtml(prefix+name)}${args ? " "+escapeHtml(args) : ""}</code><p>${escapeHtml(description)}</p><small>${escapeHtml(detail)}</small></article>`).join("")}</div></section><aside class="card"><div class="card-head"><div><h3><span class="head-icon">✦</span> Como usar</h3><p>Exemplos rápidos para moderação.</p></div></div><div class="command-examples">• ${escapeHtml(prefix)}ban @membro motivo<br/>• ${escapeHtml(prefix)}mute @membro 10m motivo<br/>• ${escapeHtml(prefix)}warn @membro motivo<br/>• ${escapeHtml(prefix)}punições @membro<br/>• ${escapeHtml(prefix)}clear 50 @membro<br/><br/><strong>Prefixo atual:</strong> <code>${escapeHtml(prefix)}</code><br/><br/>As permissões do executor, as permissões da Futaba e a hierarquia de cargos são verificadas pelo próprio bot. <br/><br/><button class="button-primary" data-open="general">Ajustar prefixo</button></div></aside></div>`;
  bindOpenButtons();
}
function renderPunishments() {
  const general = state.config.general || {};
  const embed = general.punishmentEmbed || {};
  const punishmentColor = embed.color && embed.color.toUpperCase() !== "#FF963F" ? embed.color : "#E91549";
  $("#content").innerHTML = `<div class="two-column">
    <div class="editor-main">
      <section class="card"><div class="card-head"><div><h2><span class="head-icon">⚖</span> Destino dos registros</h2><p>Escolha onde a Futaba publicará os registros de punição e ações administrativas.</p></div></div><form id="punishment-form"><div class="general-settings"><div class="field full"><label for="punish-channel">Canal de punições e ações</label>${state.resources?.channels?.length ? `<select id="punish-channel" name="logChannelId"><option value="">Selecione um canal</option>${state.resources.channels.map(channel => `<option value="${escapeAttr(channel.id)}" ${general.logChannelId === channel.id ? "selected" : ""}>${escapeHtml(channel.parentName ? `${channel.parentName} / #${channel.name}` : `#${channel.name}`)}</option>`).join("")}${general.logChannelId && !state.resources.channels.some(channel=>channel.id===general.logChannelId) ? `<option value="${escapeAttr(general.logChannelId)}" selected>ID salvo: ${escapeHtml(general.logChannelId)}</option>` : ""}</select>` : `<input id="punish-channel" name="logChannelId" value="${escapeAttr(general.logChannelId || "")}" placeholder="Cole o ID do canal de logs"/>`}<small>Recebe registros de ban, unban, kick, mute, unmute, warn, unwarn, lock, unlock e clear.</small></div></div>
      <div class="card-head"><div><h3><span class="head-icon">▧</span> Aparência do registro</h3><p>Personalize o registro publicado no canal de moderação.</p></div></div><div class="general-settings">
        <div class="field full"><label>Título</label><input name="title" value="${escapeAttr(embed.title && !/veredito foi declarado/i.test(embed.title) ? embed.title : "Registro de punição")}"/></div>
        <div class="field full"><label>Descrição</label><textarea name="description">${escapeHtml(embed.description && !/juiz declarou|sentença é/i.test(embed.description) ? embed.description : "Uma ação de moderação foi registrada no servidor.")}</textarea><small>Variáveis disponíveis: {user}, {userId}, {moderator}, {moderatorId}, {reason}, {duration}, {type}.</small></div>
        <div class="field"><label>Cor hexadecimal</label><input name="color" value="${escapeAttr(punishmentColor)}" placeholder="#E91549"/></div>
        <div class="field"><label>Rodapé</label><input name="footer" value="${escapeAttr(embed.footer && !/tribunal de fontaine/i.test(embed.footer) ? embed.footer : "POOL PARTY • Registros de moderação")}"/></div>
        <div class="field"><label>Autor</label><input name="author" value="${escapeAttr(embed.author && !/tribunal de fontaine/i.test(embed.author) ? embed.author : "Futaba Sakura • Moderação")}"/></div>
        <div class="field"><label>Ícone do autor (HTTPS)</label><input name="authorIconUrl" type="url" value="${escapeAttr(embed.authorIconUrl || "")}"/></div>
        <div class="field"><label>Ícone do rodapé (HTTPS)</label><input name="footerIconUrl" type="url" value="${escapeAttr(embed.footerIconUrl || "")}"/></div>
        <div class="field"><label>Imagem (URL HTTPS)</label><input name="imageUrl" type="url" value="${escapeAttr(embed.imageUrl || "")}"/></div>
        <div class="field"><label>Miniatura (URL HTTPS)</label><input name="thumbnailUrl" type="url" value="${escapeAttr(embed.thumbnailUrl || "")}"/></div>
        <div class="field full"><label>Campos adicionais (nome|valor|inline)</label><textarea name="fields">${escapeHtml((embed.fields || []).join("\n"))}</textarea><small>Um campo por linha. Use true ou false no terceiro valor para controlar o alinhamento.</small></div>
        <div class="field"><label>Opções do embed</label><label class="check-field"><input type="checkbox" name="timestamp" ${embed.timestamp !== false ? "checked" : ""}/> Mostrar data e horário</label><label class="check-field"><input type="checkbox" name="includeDefaultFields" ${embed.includeDefaultFields !== false ? "checked" : ""}/> Incluir campos padrão da punição</label></div>
      </div><div class="form-actions"><small>O histórico é mantido pelo bot no armazenamento persistente.</small><button class="button-primary" type="submit">▣ Salvar registros</button></div></form></section>
      <div class="tip-card"><span class="tip-icon">♡</span><h3>Como funciona o histórico</h3><p>O bot mantém os registros persistentes e o comando <strong>!punições @membro</strong> consulta o histórico, inclusive para membros que saíram do servidor. Esta página configura a publicação e a aparência; ela não exibe uma tabela de histórico, pois a API atual não expõe esses registros ao site.</p></div>
    </div>
    <aside class="editor-aside"><div class="card"><div class="card-head"><div><h3><span class="head-icon">◉</span> Prévia do registro</h3><p>Modelo ilustrativo do registro de punição.</p></div></div><div class="punishment-preview"><div class="punishment-embed" id="punishment-preview" style="--punish-color:${escapeAttr(punishmentColor)}"><div class="tribunal" id="punish-author">${escapeHtml((embed.author && !/tribunal de fontaine/i.test(embed.author) ? embed.author : "Futaba Sakura • Moderação"))}</div><h3 id="punish-title">${escapeHtml((embed.title && !/veredito foi declarado/i.test(embed.title) ? embed.title : "Registro de punição"))}</h3><p id="punish-description">${escapeHtml((embed.description && !/juiz declarou|sentença é/i.test(embed.description) ? embed.description : "Uma ação de moderação foi registrada no servidor."))}</p><div class="punishment-defaults" ${embed.includeDefaultFields === false ? "hidden" : ""}><div><strong>Membro</strong>@Membro</div><div><strong>Moderador</strong>@Moderador</div><div><strong>Motivo</strong>Exemplo de motivo</div><div><strong>Duração</strong>Permanente / sem duração</div><div><strong>Estado</strong>Ativa</div><div><strong>Data e horário</strong>Hoje</div></div>${embed.thumbnailUrl ? `<img id="punish-thumbnail" class="punish-thumbnail" src="${escapeAttr(embed.thumbnailUrl)}" alt="Miniatura do embed"/>` : `<img id="punish-thumbnail" class="punish-thumbnail" alt="" hidden/>`}${embed.imageUrl ? `<img id="punish-image" src="${escapeAttr(embed.imageUrl)}" alt="Imagem do embed"/>` : `<img id="punish-image" alt="" hidden/>`}<div class="preview-footer" id="punish-footer">${escapeHtml((embed.footer && !/tribunal de fontaine/i.test(embed.footer) ? embed.footer : "POOL PARTY • Registros de moderação"))}</div></div></div></div><div class="tip-card"><span class="tip-icon">✦</span><h3>Registro completo</h3><p>O registro contém membro, ID, moderador, tipo de punição, motivo, duração, estado e data. Os campos automáticos podem ser mantidos para preservar essas informações.</p></div></aside>
  </div>`;
  const form = $("#punishment-form");
  form.addEventListener("submit", savePunishments);
  form.addEventListener("input", updatePunishmentPreview);
}
function updatePunishmentPreview() {
  const form = $("#punishment-form"); if (!form) return;
  const get = name => form.elements[name]?.value || "";
  const color = get("color");
  $("#punish-author").textContent = get("author") || "Futaba Sakura • Moderação";
  $("#punish-title").textContent = get("title") || "Registro de punição";
  $("#punish-description").textContent = get("description") || "Uma ação de moderação foi registrada no servidor.";
  $("#punish-footer").textContent = get("footer") || "POOL PARTY • Registros de moderação";
  $("#punishment-preview").style.setProperty("--punish-color",/^#[0-9a-f]{6}$/i.test(color) ? color : "#E91549");
  const defaults = form.querySelector("[name=includeDefaultFields]");
  const fieldHolder = form.closest(".two-column")?.querySelector(".punishment-defaults");
  if (fieldHolder) fieldHolder.hidden = !defaults.checked;
  const image = $("#punish-image"); const imageUrl = get("imageUrl");
  if (image) { image.hidden = !imageUrl; if (imageUrl) image.src = imageUrl; }
  const thumbnail = $("#punish-thumbnail"); const thumbnailUrl = get("thumbnailUrl");
  if (thumbnail) { thumbnail.hidden = !thumbnailUrl; if (thumbnailUrl) thumbnail.src = thumbnailUrl; }
}
async function savePunishments(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const patch = {
    logChannelId: form.elements.logChannelId.value.trim() || null,
    punishmentEmbed: {
      title: form.elements.title.value || "Registro de punição", description: form.elements.description.value || "Uma ação de moderação foi registrada no servidor.", color: form.elements.color.value || "#E91549", footer: form.elements.footer.value || "POOL PARTY • Registros de moderação",
      author: form.elements.author.value || "Futaba Sakura • Moderação", authorIconUrl: form.elements.authorIconUrl.value.trim() || null, footerIconUrl: form.elements.footerIconUrl.value.trim() || null,
      imageUrl: form.elements.imageUrl.value.trim() || null, thumbnailUrl: form.elements.thumbnailUrl.value.trim() || null,
      fields: form.elements.fields.value.split(/\r?\n/).map(item => item.trim()).filter(Boolean), timestamp: form.elements.timestamp.checked, includeDefaultFields: form.elements.includeDefaultFields.checked
    }
  };
  await savePatch("general",patch,form.querySelector("button[type=submit]"));
}
function renderGeneral() {
  const general = state.config.general || {};
  $("#content").innerHTML = `<section class="card"><div class="card-head"><div><h2><span class="head-icon">⚙</span> Preferências de moderação</h2><p>Estas opções são compartilhadas pelos comandos manuais da Futaba.</p></div></div><form id="general-form"><div class="general-settings"><div class="field"><label for="prefix">Prefixo dos comandos</label><input id="prefix" name="prefix" value="${escapeAttr(general.prefix || "!")}" maxlength="3"/><small>De 1 a 3 caracteres, sem espaço nem menções.</small></div><div class="field"><label for="clear-count">Quantidade padrão do !clear @membro</label><input id="clear-count" name="defaultClearCount" type="number" min="1" max="1000" value="${Number(general.defaultClearCount || 50)}"/><small>O comando aceita uma quantidade explícita de até 1.000 mensagens.</small></div></div><div class="form-actions"><small>Salve para aplicar o novo prefixo no servidor.</small><button class="button-primary" type="submit">▣ Salvar preferências</button></div></form></section><div class="section-intro"><div><h2>Comandos vinculados</h2><p>O prefixo configurado acima será usado por todos estes comandos.</p></div><button class="button-secondary" data-open="commands">Ver todos os comandos</button></div>`;
  $("#general-form").addEventListener("submit", saveGeneral);
  bindOpenButtons();
}
async function saveGeneral(event) {
  event.preventDefault(); const form = event.currentTarget;
  const patch = { prefix: form.elements.prefix.value.trim() || "!", defaultClearCount: Number(form.elements.defaultClearCount.value) };
  await savePatch("general",patch,form.querySelector("button[type=submit]"));
}
function renderAbout() {
  $("#content").innerHTML = `<section class="card about-hero"><div class="about-copy"><div class="soft-label">ASSISTENTE DE MODERAÇÃO • POOL PARTY</div><h2><span>Futaba Sakura</span> • Sistema de moderação</h2><p>Este painel permite configurar os oito módulos de proteção, personalizar mensagens e registros de moderação, consultar os comandos manuais e ajustar as proteções do servidor.</p><p>O acesso é restrito a administradores do POOL PARTY e cada alteração é validada pelo backend antes de chegar à API privada do bot.</p><div class="status-pill on">Painel conectado ao Discord</div></div><div class="about-art" role="img" aria-label="Arte de referência da Futaba Sakura"></div></section><div class="section-intro"><div><h2>Recursos do painel</h2><p>O que pode ser configurado nesta versão.</p></div></div><section class="module-catalog"><article class="module-tile"><div class="tile-top"><span class="tile-icon">◈</span><strong>Proteções</strong></div><p>Oito módulos independentes, com canais, regras, limites, listas e alertas.</p></article><article class="module-tile"><div class="tile-top"><span class="tile-icon">⚖</span><strong>Moderação</strong></div><p>Comandos manuais, prefixo configurável e verificação de permissões pelo bot.</p></article><article class="module-tile"><div class="tile-top"><span class="tile-icon">▧</span><strong>Registros</strong></div><p>Canal de punições, personalização dos registros de moderação e histórico persistente no bot.</p></article></section>`;
}
async function savePatch(module,patch,button) {
  if (state.busy) return;
  state.busy = true;
  const originalText = button?.textContent;
  if (button) { button.disabled = true; button.textContent = "Salvando..."; }
  try {
    const data = await api("/api/settings",{ method:"PATCH", body:JSON.stringify({ module,patch }) });
    state.config = data.config;
    render();
    toast("Configuração salva com sucesso no POOL PARTY.");
  } catch (error) {
    toast(error.message || "Não foi possível salvar as configurações.",true);
    if (button) { button.disabled = false; button.textContent = originalText || "Salvar"; }
  } finally { state.busy = false; }
}
function renderAppealsSettings() {
  const cfg = state.config.appeals || {};
  const roles = state.resources?.roles || [];
  const channels = state.resources?.channels || [];
  const roleSelect = (key, label, hint) => `<div class="field full"><label for="appeals-${key}">${label}</label>${roles.length ? `<select id="appeals-${key}" name="${key}" multiple size="5">${roles.map(role => `<option value="${escapeAttr(role.id)}" ${(cfg[key] || []).includes(role.id) ? "selected" : ""}>${escapeHtml(role.name)} — ${escapeHtml(role.id)}</option>`).join("")}</select>` : `<textarea id="appeals-${key}" name="${key}" spellcheck="false">${escapeHtml((cfg[key] || []).join("\n"))}</textarea>`}<small>${hint}${roles.length ? "" : " • Recursos indisponíveis: informe um ID por linha para não apagar a configuração existente."}</small></div>`;
  const channelOptions = channels.length ? [`<option value="">Selecione um canal</option>`, ...channels.map(channel => `<option value="${escapeAttr(channel.id)}" ${cfg.alertChannelId === channel.id ? "selected" : ""}>#${escapeHtml(channel.name)} — ${escapeHtml(channel.id)}</option>`)].join("") : null;
  $('#content').innerHTML = `
    <section class="module-hero" style="--module-banner:url('/assets/module-banner-red.jpg')"><div class="module-hero-copy"><span class="module-kicker">POOL PARTY <b> / </b> ATENDIMENTO</span><h2>Central de Apelações</h2><p>Defina quem pode visualizar, assumir, decidir e administrar os atendimentos.</p></div><div class="module-hero-state">${cfg.active === false ? "Central desativada" : "Central habilitada"}</div></section>
    <div class="module-toolbar"><div class="module-toolbar-main"><span class="module-big-icon">▣</span><div><h2>Configurações da Central</h2><p>O acesso é verificado no backend em cada operação.</p></div></div><a class="button-primary" href="/appeals-staff.html">Abrir Central da equipe ↗</a></div>
    <form id="appeals-settings-form">
      <section class="card editor-section active"><div class="card-head"><div><h3>Permissões da equipe</h3><p>Administradores do servidor sempre mantêm acesso completo. Configure os cargos de alta staff abaixo.</p></div></div><div class="field-grid">
        ${roleSelect("viewRoleIds","Cargos que podem visualizar","Também podem acessar perfis e o histórico de atendimentos.")}
        ${roleSelect("assumeRoleIds","Cargos que podem assumir","Só esses cargos (e administradores) podem se tornar responsáveis.")}
        ${roleSelect("decideRoleIds","Cargos que podem aceitar ou rejeitar","A decisão exige justificativa e fica registrada.")}
        ${roleSelect("manageRoleIds","Cargos que podem transferir, liberar e gerenciar","Permissão de gestão da fila e das atribuições.")}
      </div></section>
      <section class="card editor-section active"><div class="card-head"><div><h3>Notificações e limites</h3><p>Configure o canal de alertas e os limites de envio.</p></div></div><div class="field-grid">
        <div class="field full"><label for="appeals-alertChannelId">Canal de alertas</label>${channelOptions ? `<select id="appeals-alertChannelId" name="alertChannelId">${channelOptions}</select>` : `<input id="appeals-alertChannelId" name="alertChannelId" value="${escapeAttr(cfg.alertChannelId || "")}" placeholder="ID do canal do Discord"/>`}<small>Quando uma apelação ou nova mensagem chegar, a Futaba publicará um aviso nesse canal.${channelOptions ? "" : " Recursos indisponíveis: informe o ID do canal."}</small></div>
        <div class="field"><label for="appeals-maxActivePerMember">Máximo de apelações abertas por membro</label><input id="appeals-maxActivePerMember" name="maxActivePerMember" type="number" min="1" max="10" value="${Number(cfg.maxActivePerMember || 3)}"/></div>
        <div class="field"><label for="appeals-maxAttachments">Imagens por apelação (até 8)</label><input id="appeals-maxAttachments" name="maxAttachments" type="number" min="0" max="8" value="${Number(cfg.maxAttachments ?? 8)}"/></div>
        <div class="field"><label>Notificar membro quando a staff responder</label><label class="toggle-control"><input type="checkbox" name="notifyMemberOnStaffMessage" ${cfg.notifyMemberOnStaffMessage !== false ? "checked" : ""}/><span class="toggle-track"></span></label></div>
        <div class="field"><label>Notificar staff quando o membro responder</label><label class="toggle-control"><input type="checkbox" name="notifyStaffOnMemberMessage" ${cfg.notifyStaffOnMemberMessage !== false ? "checked" : ""}/><span class="toggle-track"></span></label></div>
        <div class="field full"><label for="appeals-openingMessage">Mensagem de abertura</label><textarea id="appeals-openingMessage" name="openingMessage" maxlength="1000">${escapeHtml(cfg.openingMessage || "")}</textarea></div>
        <div class="field full"><label for="appeals-acceptedMessage">Mensagem ao aceitar</label><textarea id="appeals-acceptedMessage" name="acceptedMessage" maxlength="1000">${escapeHtml(cfg.acceptedMessage || "")}</textarea></div>
        <div class="field full"><label for="appeals-rejectedMessage">Mensagem ao rejeitar</label><textarea id="appeals-rejectedMessage" name="rejectedMessage" maxlength="1000">${escapeHtml(cfg.rejectedMessage || "")}</textarea></div>
        <div class="field full"><label><input type="checkbox" name="active" ${cfg.active !== false ? "checked" : ""}/> Central de Apelações ativa</label><small>Desativar impede novos envios e atendimentos até a reativação.</small></div>
      </div><div class="form-actions"><small>As permissões são conferidas diretamente no Discord e no backend.</small><button class="button-primary" type="submit">Salvar configurações</button></div></section>
    </form>`;
  $('#appeals-settings-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector('button[type="submit"]');
    const patch = {};
    for (const key of ["viewRoleIds","assumeRoleIds","decideRoleIds","manageRoleIds"]) {
      const control = form.elements.namedItem(key);
      patch[key] = control instanceof HTMLSelectElement ? Array.from(control.selectedOptions).map(option => option.value) : control.value.split(/\r?\n/).map(value => value.trim()).filter(Boolean);
    }
    patch.alertChannelId = form.elements.alertChannelId.value.trim() || null;
    patch.maxActivePerMember = Number(form.elements.maxActivePerMember.value);
    patch.maxAttachments = Number(form.elements.maxAttachments.value);
    patch.notifyMemberOnStaffMessage = form.elements.notifyMemberOnStaffMessage.checked;
    patch.notifyStaffOnMemberMessage = form.elements.notifyStaffOnMemberMessage.checked;
    patch.openingMessage = form.elements.openingMessage.value;
    patch.acceptedMessage = form.elements.acceptedMessage.value;
    patch.rejectedMessage = form.elements.rejectedMessage.value;
    patch.active = form.elements.active.checked;
    button.disabled = true; button.textContent = "Salvando...";
    try {
      const result = await api("/api/settings", { method: "PATCH", body: JSON.stringify({ module: "appeals", patch }) });
      state.config = result.config; toast("Configurações da Central salvas com sucesso.");
      renderAppealsSettings();
    } catch (error) { toast(error.message, true); button.disabled = false; button.textContent = "Salvar configurações"; }
  });
}

function bindOpenButtons() { document.querySelectorAll("[data-open]").forEach(button => button.addEventListener("click",() => setPage(button.dataset.open))); }
function setUserIdentity(user) {
  const name = displayName();
  const initial = (name.trim()[0] || "A").toUpperCase();
  $("#profile-name").textContent = name;
  $("#top-user-name").textContent = name;
  $("#profile-avatar").textContent = initial;
  $("#top-avatar").textContent = initial;
  if (user?.avatar && user?.id) {
    const avatarUrl = `https://cdn.discordapp.com/avatars/${encodeURIComponent(user.id)}/${encodeURIComponent(user.avatar)}.png?size=96`;
    $("#top-avatar").style.background = `center/cover url('${avatarUrl}')`;
    $("#top-avatar").textContent = "";
    $("#profile-avatar").style.background = `center/cover url('${avatarUrl}')`;
    $("#profile-avatar").textContent = "";
  }
}
async function init() {
  const loginFlag = new URLSearchParams(location.search).get("login");
  try {
    const auth = await api("/api/auth/me");
    state.user = auth.user;
    state.config = (await api("/api/settings")).config;
    state.resources = await api("/api/resources").catch(() => null);
    setUserIdentity(auth.user);
    switchToDashboard();
    setPage("home");
  } catch (error) {
    $("#welcome").classList.remove("hidden");
    if (loginFlag === "invalid" || loginFlag === "error") toast("Não foi possível concluir o login pelo Discord. Tente entrar novamente.",true);
  }
  document.querySelectorAll(".nav-item[data-page]").forEach(button => button.addEventListener("click",() => setPage(button.dataset.page)));
  $("#logout").addEventListener("click",async () => { await api("/api/auth/logout",{ method:"POST" }).catch(() => null); location.href = "/"; });
  $("#mobile-nav-toggle").addEventListener("click",() => { const open = $("#dashboard").classList.toggle("nav-open"); $("#mobile-nav-toggle").setAttribute("aria-expanded",String(open)); });
  $("#dashboard").addEventListener("click",event => { if (event.target === $("#dashboard")) { $("#dashboard").classList.remove("nav-open"); $("#mobile-nav-toggle").setAttribute("aria-expanded","false"); } });
  if (loginFlag) history.replaceState({},"","/");
}
init();
