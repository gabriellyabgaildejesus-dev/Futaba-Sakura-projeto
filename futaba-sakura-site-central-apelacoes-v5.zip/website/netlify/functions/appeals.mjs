import { json, requireDiscordUserSession, botApi } from "./_shared.mjs";

function parseBody(event) {
  try { return JSON.parse(event.body || "{}"); }
  catch { return null; }
}

export async function handler(event) {
  const auth = await requireDiscordUserSession(event);
  if (auth.error) return auth.error;
  const guildId = process.env.POOL_PARTY_GUILD_ID || "";
  if (!/^\d{17,20}$/.test(guildId)) return json(503, { error: "POOL_PARTY_GUILD_ID ainda não foi configurado no Netlify." });
  const query = event.queryStringParameters || {};
  const base = `/api/v1/guilds/${guildId}/appeals`;
  const user = auth.user;
  try {
    if (event.httpMethod === "GET" && query.action === "eligibility") {
      const data = await botApi(`${base}/eligibility?userId=${encodeURIComponent(user.id)}`, { method: "GET" });
      return json(200, data);
    }
    if (event.httpMethod === "GET" && query.action === "list") {
      const data = await botApi(`${base}?userId=${encodeURIComponent(user.id)}&view=${encodeURIComponent(query.view || "member")}&status=${encodeURIComponent(query.status || "")}&q=${encodeURIComponent(query.q || "")}`, { method: "GET" });
      return json(200, data);
    }
    if (event.httpMethod === "GET" && query.action === "profile") {
      const data = await botApi(`${base}/profile?userId=${encodeURIComponent(user.id)}`, { method: "GET" });
      return json(200, data);
    }
    if (event.httpMethod === "GET" && query.action === "detail") {
      if (!/^[a-zA-Z0-9-]{6,50}$/.test(query.id || "")) return json(400, { error: "Identificador de apelação inválido." });
      const data = await botApi(`${base}/${encodeURIComponent(query.id)}?userId=${encodeURIComponent(user.id)}`, { method: "GET" });
      return json(200, data);
    }
    if (["POST", "PATCH"].includes(event.httpMethod)) {
      const body = parseBody(event);
      if (!body || typeof body !== "object" || Array.isArray(body)) return json(400, { error: "JSON inválido." });
      const payload = { ...body, actor: { id: user.id, username: user.username, globalName: user.globalName, avatar: user.avatar } };
      if (event.httpMethod === "POST" && body.action === "create") {
        const data = await botApi(base, { method: "POST", body: JSON.stringify(payload) });
        return json(201, data);
      }
      if (body.action === "message" && /^[a-zA-Z0-9-]{6,50}$/.test(body.appealId || "")) {
        const data = await botApi(`${base}/${encodeURIComponent(body.appealId)}/messages`, { method: "POST", body: JSON.stringify(payload) });
        return json(201, data);
      }
      if (["assume", "release", "transfer", "status", "call", "profile", "internal-note"].includes(body.action)) {
        const suffix = body.action === "profile" ? "/profile" : `/${encodeURIComponent(body.appealId || "")}/${body.action}`;
        const data = await botApi(`${base}${suffix}`, { method: "PATCH", body: JSON.stringify(payload) });
        return json(200, data);
      }
      return json(400, { error: "Operação de apelação desconhecida." });
    }
    return json(405, { error: "Método não permitido." }, { allow: "GET, POST, PATCH" });
  } catch (error) {
    return json(error.status || 502, { error: error.message || "Falha ao comunicar com a Central de Apelações." });
  }
}
