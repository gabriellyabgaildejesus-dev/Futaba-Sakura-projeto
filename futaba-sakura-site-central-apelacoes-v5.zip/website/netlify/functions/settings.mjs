import { botApi, json, requireAdminSession } from "./_shared.mjs";

export async function handler(event) {
  const auth = await requireAdminSession(event);
  if (auth.error) return auth.error;
  const path = `/api/v1/guilds/${auth.guildId}/config`;
  try {
    if (event.httpMethod === "GET") {
      const data = await botApi(path, { method: "GET" });
      return json(200, data);
    }
    if (event.httpMethod === "PATCH") {
      let body;
      try { body = JSON.parse(event.body || "{}"); }
      catch { return json(400, { error: "JSON inválido." }); }
      const allowed = new Set(["antiSpam", "antiFlood", "mentionSpam", "autoMod", "antiBot", "antiRaid", "antiNuke", "antiLink", "general", "appeals"]);
      if (!allowed.has(body.module) || !body.patch || typeof body.patch !== "object" || Array.isArray(body.patch)) return json(400, { error: "Alteração de configuração inválida." });
      const result = await botApi(path, { method: "PATCH", body: JSON.stringify(body) });
      return json(200, result);
    }
    return json(405, { error: "Método não permitido." }, { allow: "GET, PATCH" });
  } catch (error) {
    return json(error.status || 502, { error: error.message || "Falha ao comunicar com a Futaba." });
  }
}
