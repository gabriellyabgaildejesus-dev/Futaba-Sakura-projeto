import { clearSessionCookie, json } from "./_shared.mjs";

export async function handler() {
  return { ...json(200, { ok: true }), headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "set-cookie": clearSessionCookie() } };
}
