import { botApi, json, requireAdminSession } from "./_shared.mjs";

export async function handler(event) {
  const auth = await requireAdminSession(event);
  if (auth.error) return auth.error;
  if (event.httpMethod !== "GET") return json(405, { error: "Método não permitido." }, { allow: "GET" });
  try {
    const data = await botApi(`/api/v1/guilds/${auth.guildId}/resources`, { method: "GET" });
    return json(200, data);
  } catch (error) {
    return json(error.status || 502, { error: error.message || "Falha ao carregar canais e cargos do Discord." });
  }
}
