import crypto from "node:crypto";
import { stateCookie, nextCookie } from "./_shared.mjs";

export async function handler(event) {
  const clientId = process.env.DISCORD_CLIENT_ID || "";
  const redirectUri = process.env.DISCORD_REDIRECT_URI || "";
  if (!clientId || !redirectUri) return { statusCode: 503, body: "Configure DISCORD_CLIENT_ID e DISCORD_REDIRECT_URI no Netlify." };
  const state = crypto.randomBytes(24).toString("base64url");
  const url = new URL("https://discord.com/oauth2/authorize");
  url.searchParams.set("client_id", clientId);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "identify guilds");
  url.searchParams.set("state", state);
  const requestedNext = event.queryStringParameters?.next || "/";
  const safeAppealNext = /^\/appeals(?:-staff)?\.html(?:\?id=FUT-[A-F0-9]{8})?$/.test(requestedNext);
  const next = safeAppealNext ? requestedNext : "/";
  return { statusCode: 302, headers: { location: url.toString() }, multiValueHeaders: { "set-cookie": [stateCookie(state), nextCookie(next)] }, body: "" };
}
