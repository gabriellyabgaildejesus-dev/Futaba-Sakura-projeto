import crypto from "node:crypto";

const COOKIE = "futaba_session";
const STATE_COOKIE = "futaba_oauth_state";
const NEXT_COOKIE = "futaba_oauth_next";
const DISCORD_API = "https://discord.com/api/v10";

export function json(statusCode, payload, extraHeaders = {}) {
  return {
    statusCode,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff", ...extraHeaders },
    body: JSON.stringify(payload)
  };
}

export function cookieValue(event, name) {
  const header = event.headers?.cookie || event.headers?.Cookie || "";
  for (const part of header.split(";")) {
    const [key, ...value] = part.trim().split("=");
    if (key === name) return decodeURIComponent(value.join("="));
  }
  return "";
}

function cookie(name, value, maxAge) {
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}

export function stateCookie(value) { return cookie(STATE_COOKIE, value, 600); }
export function clearStateCookie() { return cookie(STATE_COOKIE, "", 0); }
export function nextCookie(value) { return cookie(NEXT_COOKIE, value, 600); }
export function clearNextCookie() { return cookie(NEXT_COOKIE, "", 0); }
export function sessionCookie(value, maxAge) { return cookie(COOKIE, value, maxAge); }
export function clearSessionCookie() { return cookie(COOKIE, "", 0); }

function sessionKey() {
  const secret = process.env.SESSION_SECRET || "";
  if (secret.length < 32) throw new Error("SESSION_SECRET precisa ter pelo menos 32 caracteres.");
  return crypto.createHash("sha256").update(secret).digest();
}

export function sealSession(session) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", sessionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(session), "utf8"), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), encrypted]).toString("base64url");
}

export function openSession(value) {
  if (!value) return null;
  try {
    const raw = Buffer.from(value, "base64url");
    if (raw.length < 29) return null;
    const iv = raw.subarray(0, 12);
    const tag = raw.subarray(12, 28);
    const data = raw.subarray(28);
    const decipher = crypto.createDecipheriv("aes-256-gcm", sessionKey(), iv);
    decipher.setAuthTag(tag);
    const parsed = JSON.parse(Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8"));
    if (!parsed.expiresAt || parsed.expiresAt <= Date.now()) return null;
    return parsed;
  } catch { return null; }
}

export async function requireAdminSession(event) {
  const session = openSession(cookieValue(event, COOKIE));
  if (!session?.accessToken) return { error: json(401, { error: "Entre com sua conta Discord para continuar." }) };
  const guildId = process.env.POOL_PARTY_GUILD_ID || "";
  if (!/^\d{17,20}$/.test(guildId)) return { error: json(503, { error: "POOL_PARTY_GUILD_ID ainda não foi configurado no Netlify." }) };
  try {
    const response = await fetch(`${DISCORD_API}/users/@me/guilds`, {
      headers: { authorization: `Bearer ${session.accessToken}` }
    });
    if (!response.ok) return { error: json(401, { error: "Sua sessão Discord expirou. Entre novamente." }) };
    const guilds = await response.json();
    const guild = guilds.find(item => item.id === guildId);
    const isAdmin = Boolean(guild && (guild.owner || (BigInt(guild.permissions || "0") & 8n) === 8n));
    if (!isAdmin) return { error: json(403, { error: "Acesso exclusivo à administração do servidor POOL PARTY." }) };
    return { session, guildId, guildName: guild.name };
  } catch {
    return { error: json(502, { error: "Não foi possível validar suas permissões no Discord." }) };
  }
}

export async function botApi(path, options = {}) {
  const base = (process.env.FUTABA_BOT_API_URL || "").replace(/\/$/, "");
  const secret = process.env.FUTABA_API_SECRET || "";
  if (!base.startsWith("https://") || secret.length < 32) throw new Error("Configure FUTABA_BOT_API_URL (HTTPS) e FUTABA_API_SECRET no Netlify.");
  const response = await fetch(`${base}${path}`, {
    ...options,
    headers: { authorization: `Bearer ${secret}`, "content-type": "application/json", ...(options.headers || {}) }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(body.error || `API da Futaba respondeu ${response.status}.`), { status: response.status });
  return body;
}

export const discordApi = DISCORD_API;
export const stateCookieName = STATE_COOKIE;


export async function requireDiscordUserSession(event) {
  const session = openSession(cookieValue(event, COOKIE));
  if (!session?.accessToken || !session?.user?.id) {
    return { error: json(401, { error: "Entre com sua conta Discord para continuar." }) };
  }
  try {
    const response = await fetch(`${DISCORD_API}/users/@me`, {
      headers: { authorization: `Bearer ${session.accessToken}` }
    });
    if (!response.ok) return { error: json(401, { error: "Sua sessão Discord expirou. Entre novamente." }) };
    const user = await response.json();
    if (user.id !== session.user.id) return { error: json(401, { error: "A conta Discord da sessão não corresponde." }) };
    return { session, user: { id: user.id, username: user.username, globalName: user.global_name || user.username, avatar: user.avatar } };
  } catch {
    return { error: json(502, { error: "Não foi possível validar sua conta Discord." }) };
  }
}
