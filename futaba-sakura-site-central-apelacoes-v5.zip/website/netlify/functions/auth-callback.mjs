import { cookieValue, clearStateCookie, clearNextCookie, sealSession, sessionCookie, discordApi } from "./_shared.mjs";

export async function handler(event) {
  const query = event.queryStringParameters || Object.fromEntries(new URLSearchParams(event.rawQuery || ""));
  const code = query.code;
  const state = query.state;
  const storedState = cookieValue(event, "futaba_oauth_state");
  const requestedNext = cookieValue(event, "futaba_oauth_next");
  const safeAppealNext = /^\/appeals(?:-staff)?\.html(?:\?id=FUT-[A-F0-9]{8})?$/.test(requestedNext);
  const next = safeAppealNext ? requestedNext : "/";
  if (!code || !state || !storedState || state !== storedState) {
    return { statusCode: 302, multiValueHeaders: { "set-cookie": [clearStateCookie(), clearNextCookie()] }, headers: { location: "/?login=invalid" }, body: "" };
  }
  const clientId = process.env.DISCORD_CLIENT_ID || "";
  const clientSecret = process.env.DISCORD_CLIENT_SECRET || "";
  const redirectUri = process.env.DISCORD_REDIRECT_URI || "";
  try {
    const tokenResponse = await fetch(`${discordApi}/oauth2/token`, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, grant_type: "authorization_code", code, redirect_uri: redirectUri })
    });
    const tokens = await tokenResponse.json();
    if (!tokenResponse.ok || !tokens.access_token) throw new Error("Falha ao autenticar no Discord.");
    const userResponse = await fetch(`${discordApi}/users/@me`, { headers: { authorization: `Bearer ${tokens.access_token}` } });
    const user = await userResponse.json();
    if (!userResponse.ok) throw new Error("Não foi possível carregar a conta Discord.");
    const expiresIn = Math.max(300, Math.min(Number(tokens.expires_in || 3600), 604800));
    const expiresAt = Date.now() + expiresIn * 1000;
    const sealed = sealSession({ accessToken: tokens.access_token, user: { id: user.id, username: user.username, globalName: user.global_name || user.username, avatar: user.avatar }, expiresAt });
    return {
      statusCode: 302,
      headers: { location: `${next}${next.includes("?") ? "&" : "?"}login=ok` },
      multiValueHeaders: { "set-cookie": [sessionCookie(sealed, expiresIn), clearStateCookie(), clearNextCookie()] },
      body: ""
    };
  } catch (error) {
    console.error("[Futaba site OAuth]", error.message);
    return { statusCode: 302, headers: { location: "/?login=error" }, multiValueHeaders: { "set-cookie": [clearStateCookie(), clearNextCookie()] }, body: "" };
  }
}
