import { json, requireAdminSession } from "./_shared.mjs";

export async function handler(event) {
  const auth = await requireAdminSession(event);
  if (auth.error) return auth.error;
  return json(200, { authenticated: true, user: auth.session.user, guild: { id: auth.guildId, name: auth.guildName } });
}
