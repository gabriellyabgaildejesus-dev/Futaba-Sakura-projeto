import { json, requireDiscordUserSession, botApi } from "./_shared.mjs";

export async function handler(event) {
  const auth = await requireDiscordUserSession(event);
  if (auth.error) return auth.error;
  const guildId = process.env.POOL_PARTY_GUILD_ID || "";
  if (!/^\d{17,20}$/.test(guildId)) return json(503, { error: "POOL_PARTY_GUILD_ID ainda não foi configurado no Netlify." });
  try {
    const eligibility = await botApi(`/api/v1/guilds/${guildId}/appeals/eligibility?userId=${encodeURIComponent(auth.user.id)}`, { method: "GET" });
    return json(200, { authenticated: true, user: auth.user, eligibility });
  } catch (error) {
    return json(error.status || 502, { error: error.message || "Não foi possível consultar a Central de Apelações." });
  }
}
