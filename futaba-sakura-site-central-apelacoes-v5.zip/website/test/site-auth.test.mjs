import test from "node:test";
import assert from "node:assert/strict";
import { sealSession, openSession } from "../netlify/functions/_shared.mjs";

const originalSecret = process.env.SESSION_SECRET;
process.env.SESSION_SECRET = "test-secret-that-is-longer-than-thirty-two-characters";

test("sessão OAuth fica criptografada e pode ser validada", () => {
  const session = {
    accessToken: "discord-access-token",
    user: { id: "123456789012345678", username: "admin" },
    expiresAt: Date.now() + 60_000
  };
  const sealed = sealSession(session);
  assert.equal(sealed.includes("discord-access-token"), false);
  assert.deepEqual(openSession(sealed), session);
});

test("sessão adulterada ou expirada é rejeitada", () => {
  const sealed = sealSession({ accessToken: "token", expiresAt: Date.now() + 60_000 });
  const alteredBytes = Buffer.from(sealed, "base64url");
  alteredBytes[alteredBytes.length - 1] ^= 1;
  const tampered = alteredBytes.toString("base64url");
  assert.equal(openSession(tampered), null);
  const expired = sealSession({ accessToken: "token", expiresAt: Date.now() - 1 });
  assert.equal(openSession(expired), null);
});

test("segredo curto não pode ser usado para criar sessão", () => {
  process.env.SESSION_SECRET = "short";
  assert.throws(() => sealSession({ expiresAt: Date.now() + 60_000 }), /32 caracteres/);
  process.env.SESSION_SECRET = "test-secret-that-is-longer-than-thirty-two-characters";
});

test.after(() => {
  if (originalSecret === undefined) delete process.env.SESSION_SECRET;
  else process.env.SESSION_SECRET = originalSecret;
});

import { handler as authStart } from "../netlify/functions/auth-start.mjs";
import { handler as authCallback } from "../netlify/functions/auth-callback.mjs";

test("OAuth preserva o destino direto de uma apelação e rejeita redirecionamentos externos", async () => {
  const oldClient = process.env.DISCORD_CLIENT_ID;
  const oldRedirect = process.env.DISCORD_REDIRECT_URI;
  process.env.DISCORD_CLIENT_ID = "123456789012345678";
  process.env.DISCORD_REDIRECT_URI = "https://example.netlify.app/.netlify/functions/auth-callback";
  const ticket = await authStart({ queryStringParameters: { next: "/appeals.html?id=FUT-ABCDEF12" } });
  assert.match(ticket.headers.location, /discord.com\/oauth2\/authorize/);
  assert.ok(ticket.multiValueHeaders["set-cookie"].some(value => decodeURIComponent(value).includes("/appeals.html?id=FUT-ABCDEF12")));
  const external = await authStart({ queryStringParameters: { next: "https://evil.example/steal" } });
  assert.equal(external.multiValueHeaders["set-cookie"].some(value => decodeURIComponent(value).includes("evil.example")), false);
  if (oldClient === undefined) delete process.env.DISCORD_CLIENT_ID; else process.env.DISCORD_CLIENT_ID = oldClient;
  if (oldRedirect === undefined) delete process.env.DISCORD_REDIRECT_URI; else process.env.DISCORD_REDIRECT_URI = oldRedirect;
});

test("callback OAuth retorna à apelação solicitada depois de autenticar", async () => {
  const oldClient = process.env.DISCORD_CLIENT_ID;
  const oldSecret = process.env.DISCORD_CLIENT_SECRET;
  const oldRedirect = process.env.DISCORD_REDIRECT_URI;
  const oldFetch = globalThis.fetch;
  process.env.DISCORD_CLIENT_ID = "123456789012345678";
  process.env.DISCORD_CLIENT_SECRET = "test-client-secret";
  process.env.DISCORD_REDIRECT_URI = "https://example.netlify.app/.netlify/functions/auth-callback";
  globalThis.fetch = async url => String(url).includes("/oauth2/token")
    ? { ok: true, json: async () => ({ access_token: "test-access-token", expires_in: 3600 }) }
    : { ok: true, json: async () => ({ id: "123456789012345678", username: "member", global_name: "Member", avatar: null }) };
  const result = await authCallback({
    queryStringParameters: { code: "test-code", state: "state-ok" },
    headers: { cookie: "futaba_oauth_state=state-ok; futaba_oauth_next=%2Fappeals.html%3Fid%3DFUT-ABCDEF12" }
  });
  assert.equal(result.headers.location, "/appeals.html?id=FUT-ABCDEF12&login=ok");
  assert.equal(result.multiValueHeaders["set-cookie"].length, 3);
  globalThis.fetch = oldFetch;
  if (oldClient === undefined) delete process.env.DISCORD_CLIENT_ID; else process.env.DISCORD_CLIENT_ID = oldClient;
  if (oldSecret === undefined) delete process.env.DISCORD_CLIENT_SECRET; else process.env.DISCORD_CLIENT_SECRET = oldSecret;
  if (oldRedirect === undefined) delete process.env.DISCORD_REDIRECT_URI; else process.env.DISCORD_REDIRECT_URI = oldRedirect;
});
