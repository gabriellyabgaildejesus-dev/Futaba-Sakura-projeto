# Site Futaba Sakura — Netlify

Este diretório contém o frontend estático e as Netlify Functions do painel da Futaba Sakura. O painel administrativo é exclusivo dos Administradores/proprietários do POOL PARTY. A Central de Apelações autentica qualquer conta Discord e valida no backend a titularidade da solicitação ou os cargos específicos da alta staff.

## Publicar

1. Publique a pasta do projeto na raiz do site Netlify. O `netlify.toml` já configura `public/` como diretório publicado e `netlify/functions/` como diretório das funções.
2. No Discord Developer Portal, configure o OAuth2 Redirect URI exatamente como `https://SEU-SITE.netlify.app/.netlify/functions/auth-callback` e habilite os escopos `identify` e `guilds`.
3. Cadastre no painel Environment variables do Netlify:
   - `DISCORD_CLIENT_ID`
   - `DISCORD_CLIENT_SECRET`
   - `DISCORD_REDIRECT_URI`
   - `SESSION_SECRET` (segredo aleatório com ao menos 32 caracteres; por exemplo `openssl rand -hex 32`)
   - `FUTABA_BOT_API_URL` (URL HTTPS pública da API privada do bot)
   - `FUTABA_API_SECRET` (o mesmo segredo configurado na hospedagem do bot)
   - `POOL_PARTY_GUILD_ID` (ID real do servidor POOL PARTY)
4. Na hospedagem do bot, configure `API_PORT`, `FUTABA_API_SECRET`, `POOL_PARTY_GUILD_ID` e `API_ALLOWED_GUILD_IDS`. Os dois últimos IDs precisam ser idênticos; `API_ALLOWED_GUILD_IDS` deve conter **somente** o ID do POOL PARTY. A API recusa iniciar se isso não for verdade.
5. Mantenha o processo Discord Gateway rodando na hospedagem do bot. O Netlify hospeda o site e as funções serverless, não o processo permanente do bot.

## Segurança

- Nunca coloque `DISCORD_CLIENT_SECRET`, `FUTABA_API_SECRET`, `SESSION_SECRET` ou o token do bot em `public/` ou no JavaScript do navegador.
- Configure HTTPS entre Netlify e a API do bot. Não exponha a API de configuração em HTTP aberto.
- O site usa cookie de sessão `HttpOnly`, `Secure` e `SameSite=Lax`, criptografado com AES-256-GCM.
- Cada operação administrativa valida novamente a permissão de Administrador no servidor POOL PARTY. Na Central, membros só acessam suas próprias apelações; as funções da alta staff são autorizadas por cargos independentes de visualizar, assumir, decidir e gerenciar.
- O backend permite somente configuração dos oito módulos e das configurações gerais; histórico de punições, senhas e estados internos do Anti-Bot não são enviados ao navegador.
- A rota protegida de recursos retorna apenas nomes/IDs de canais de texto e cargos para preencher seletores do painel; não disponibiliza membros nem conteúdo de mensagens.
- A Central de Apelações usa sessão OAuth criptografada, APIs privadas e verificação de permissões no bot. Membros consultam apenas as próprias solicitações; a equipe recebe permissões específicas por cargo.
- Esta versão não inclui pagamentos, assinaturas ou acesso para outros servidores.

## O que pode ser configurado

O painel possui dashboard organizado, páginas próprias para os oito módulos, página de comandos manuais, configurações gerais e página Registro de Punições. Edita canais, cargos, limites, mensagens públicas, DMs, embeds de log e alerta, whitelist de bots confiáveis (somente para o Anti-Bot), mensagens/estados da autenticação Anti-Bot, canal de punições e embed de registro de moderação. Os seletores de canais/cargos carregam dados reais do servidor pela rota privada `/api/resources`.

A página Registro de Punições configura o canal de saída e a aparência do registro publicado no Discord. A consulta do histórico continua sendo feita pelo comando `!punições`, pois a API deliberadamente não expõe o histórico persistente ao navegador.

O site não está publicado automaticamente por este pacote: é preciso enviar a pasta ao Netlify e manter as variáveis secretas já configuradas.

## Central de Apelações

- `/appeals.html`: portal de membros. O login aceita qualquer conta Discord; a API do bot verifica se a pessoa é membro ou está banida antes de permitir a abertura correspondente.
- `/appeals-staff.html`: fila e atendimento da alta staff. O acesso é concedido por cargos configurados em **Painel administrativo → Configurar Central**, ou por Administrador/ proprietário.
- A Central começa desativada por segurança. Em **Painel administrativo → Configurar Central**, selecione o canal de alertas, configure os cargos e só então ative a Central. Configure `alertChannelId`, `viewRoleIds`, `assumeRoleIds`, `decideRoleIds` e `manageRoleIds`. O canal de alertas recebe novas solicitações e mensagens dos membros.
- O fluxo de banimento exige e-mail. Para Warn/Mute, o membro confirma que as DMs estão habilitadas. O bot não acessa a caixa de entrada do usuário.
- O serviço de e-mail é opcional, mas necessário para convites e atualizações por e-mail de contas banidas: configure `APPEALS_EMAIL_API_KEY` e `APPEALS_EMAIL_FROM` no host do bot (integração Resend, com domínio de remetente verificado). Configure `PUBLIC_SITE_URL` para os links públicos. Os links de aviso abrem diretamente a solicitação, inclusive depois do login Discord.
- Os registros, mensagens, decisões, perfis e anexos são mantidos em `data/appeals.json` no host do bot. Preserve esse arquivo em atualizações e inclua-o nos backups. A pasta de dados precisa estar em armazenamento persistente.
- Imagens: até 8 por apelação, formatos PNG/JPEG/WEBP/GIF, 600 KB por arquivo e 3 MB no total. Mensagens permitem até 4 imagens, com total de 2 MB.
- O bot precisa de permissões para consultar membros e bans, enviar mensagens no canal de alertas e enviar DMs. Para consultar banimentos, conceda `Ban Members`/`Banear membros` ao bot. A integração de e-mail usa chave secreta só no host do bot.
- Aceitar uma apelação registra a decisão; não executa automaticamente unban/unmute. A ação de moderação deve ser feita separadamente após revisão humana.


## Interface e responsividade

A página pública utiliza a composição Phantom Thieves aprovada (preto, vermelho, branco e acentos rosa), com o acesso via Discord em destaque. A área autenticada tem navegação lateral, dashboard e páginas individuais para cada módulo. Nas páginas de módulos, as categorias de configuração são exibidas por abas; apenas uma categoria fica aberta por vez, e os campos ficam em coluna única para evitar fileiras extensas. Dois banners fornecidos pela administração alternam entre as páginas dos módulos. O layout adapta navegação, formulários, cards e prévias para telas móveis.
